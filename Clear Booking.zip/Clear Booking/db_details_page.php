<?php
/*
 * Template Name: Custom Full Width
 * Description: Page template without sidebar
 */


?>

<html>

<body onload="myFunction('<?php echo $_REQUEST[resID]; ?>')">

<?php get_header(); ?>

<div id="primary" class="site-content">

<div id="content" role="main" class="container-fluid">
 
</div><!-- #content -->

</div><!-- #primary -->

<?php get_footer(); ?>

</body>

</html>
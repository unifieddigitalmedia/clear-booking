<?php



    /*
      /*
    Plugin Name: Clear Booking
    Plugin URI: https://clear-booking.herokuapp.com
    Description: Plugin for displaying places of interest in Portland Jamaica
    Author: M. Slack
    Version: 1.0
    Author URI: http://unifieddigitalmedia.herokuapp.com

   Travel Light is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 2 of the License, or
   any later version.
 
   Travel Lightis distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
   GNU General Public License for more details.
 
   You should have received a copy of the GNU General Public License
   along with Clear Booking. If not, see http://www.gnu.org/licenses/gpl-2.0.html.

   */


defined( 'ABSPATH' ) or die( 'Plugin file cannot be accessed directly.' );


spl_autoload_register(function ($class) {



if (file_exists(dirname( __FILE__ ) . '/admin/'. $class .'.php')) {


include dirname( __FILE__ ) . '/admin/'. $class .'.php';

}

else 

{


include dirname( __FILE__ ) . '/includes/'. $class .'.php';


}




});


if ( is_admin() ) {




  register_activation_hook( __FILE__, 'db_reserve_database_ini::db_rooms_create' );

  register_activation_hook( __FILE__, 'db_reserve_database_ini::db_coupons_create' );

  register_activation_hook( __FILE__, 'db_reserve_database_ini::db_bookings_create' );

  register_activation_hook( __FILE__, 'db_reserve_database_ini::db_resrvations_create' );

  register_activation_hook( __FILE__, 'db_reserve_database_ini::db_reservation_coupons_create' );

  register_activation_hook( __FILE__, 'db_reserve_database_ini::db_add_ons_create' );

  register_activation_hook( __FILE__, 'db_reserve_database_ini::db_reservation_add_ons_create' );

  register_activation_hook( __FILE__, 'db_reserve_database_ini::db_members_create' );
  
  register_activation_hook( __FILE__, 'db_reserve_database_ini::db_users_create' );



  add_action( 'init', 'db_reserve_custom_posts::db_custom_posts_rooms_create' );

  add_action( 'init', 'db_reserve_custom_posts::db_custom_posts_coupons_create' );

  add_action( 'init', 'db_reserve_custom_posts::db_custom_posts_categories_create' );

  add_action( 'init', 'db_reserve_custom_posts::db_custom_posts_add_ons_create' );

  add_action( 'init','db_reserve_custom_posts_meta::db_reserve_custom_posts_meta_' );

  add_action('save_post', 'db_reserve_custom_posts_meta::db_reserve_custom_posts_meta_save', 10, 2 );

  add_action('admin_menu', 'db_reserve_menu_items::db_reserve_menu_items_create');

  add_action( 'admin_enqueue_scripts', 'db_reserve_enqueues::db_reserve_enqueues_admin');

  db_reserve_class_rooms::db_reserve_class_rooms_();

  db_reserve_class_offers::db_reserve_class_offers_();

  db_reserve_class_booking::db_reserve_class_booking_();

  db_reserve_class_total::db_reserve_class_total_();

  db_reserve_class_loadcal::db_reserve_class_loadcal_();

  db_reserve_class_loadcalto::db_reserve_class_loadcalto_();

  db_reserve_class_resdetails::db_reserve_class_resdetails_();

   db_sign_up::db_sign_up_();


}

else

{
 add_action('wp_enqueue_scripts', 'db_reserve_enqueues::db_reserve_enqueues_'); 

 add_filter('the_content', 'db_reserve_content::db_reserve_details_');  

 db_reserve_shortcode::init();

}

?>
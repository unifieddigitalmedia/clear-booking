<?php
 
class db_reserve_enqueues

{
  




public static function db_reserve_enqueues_admin()
  

{
    


    wp_enqueue_script( 'jquery-ui-datepicker' );

    wp_register_script('jqs_js2','http://code.jquery.com/jquery-1.10.2.js',false,false,true );

    wp_enqueue_script('jqs_js2'); 

    wp_register_script('jqs_js1','http://code.jquery.com/ui/1.11.4/jquery-ui.js',false,false,true );

    wp_enqueue_script('jqs_js1'); 

    wp_enqueue_style( 'jquery-style', 'http://ajax.googleapis.com/ajax/libs/jqueryui/1.8.2/themes/smoothness/jquery-ui.css' );

    wp_register_script('db_main_js',plugins_url('DragonBayInnReserve/js/db_reserve_js_script.js',_FILE_ ),array('jquery') ,'1.0.0', true ); 

    wp_enqueue_script('db_main_js'); 

    wp_localize_script( 'main_ajax', 'ajax_object',array( 'ajax_url' => admin_url( 'admin-ajax.php' ) ),false,false,false );


   wp_register_style( 'main_css', plugins_url('DragonBayInnReserve/css/index_admin.css',_FILE_ ) );
   
   wp_enqueue_style( 'main_css' );

}



public static function db_reserve_enqueues_() 



{


   wp_register_style( 'db_main_css', plugins_url('DragonBayInnReserve/css/index.css',_FILE_ ) );
   
   wp_enqueue_style( 'db_main_css' );

   wp_register_script('db_main_js',plugins_url('DragonBayInnReserve/js/db_reserve_js_script.js',_FILE_ ),array('jquery') ,'1.0.0', true ); 

   wp_enqueue_script('db_main_js'); 

   wp_localize_script( 'db_main_js', 'ajax_object',array( 'ajax_url' => admin_url( 'admin-ajax.php' ) ),false,false,false );


   wp_enqueue_script('jquery-ui-datepicker');

   wp_register_style('boot_css','http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css',false,false,false);

   wp_enqueue_style('boot_css'); 
 
   wp_register_script('boot_js','http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js',false,false,false);

   wp_enqueue_script('boot_js'); 

   wp_register_script('boot_js1','https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js',false,false,false);

   wp_enqueue_script('boot_js1'); 

    wp_register_script('jqs_js1','https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js',false,false,true );

   wp_enqueue_script('jqs_js1'); 

   wp_register_script('jqs_js2','http://ajax.aspnetcdn.com/ajax/jQuery/jquery-1.11.3.min.js',false,false,true );

   wp_enqueue_script('jqs_js2');



  

   wp_register_script('jqs_js3','http://code.jquery.com/jquery-1.10.2.js',false,false,true );

   wp_enqueue_script('jqs_js3'); 

   wp_register_script('jqs_js4','http://code.jquery.com/ui/1.11.4/jquery-ui.js',false,false,true );

   wp_enqueue_script('jqs_js4'); 



   wp_enqueue_style('jquery-style', 'http://ajax.googleapis.com/ajax/libs/jqueryui/1.8.2/themes/smoothness/jquery-ui.css');



 

}




}

 
?>
<?php



class db_reserve_menu_items


{


public static function db_reserve_menu_items_create()


  {



 add_menu_page('Dragon Bay Inn Reserve', 'Dragon Bay Inn Reserve', 'manage_options', 'dbreserve','mt_toplevel_page');


 add_submenu_page( 'dbreserve', 'Settings', 'Settings', 'manage_options', 'db_settings', array('db_reserve_menu_items','db_settings_submenu_page_callback'));



  }



public static function db_settings_submenu_page_callback()

{

?>




      <div class="wrap">


<?php


if(isset( $_POST['form_submitted'] ))
{




 if ( isset( $_POST['db_reservation_page'] ) ) {
 

        update_option( "db_reservation_page", sanitize_text_field( $_POST['db_reservation_page']) );
 
    } 
 if ( isset( $_POST['db_thankyou_page'] ) ) {
 

        update_option( "db_thankyou_page", sanitize_text_field( $_POST['db_thankyou_page']) );
 
    } 


 if ( isset( $_POST['db_confirmation_page'] ) ) {
 

        update_option( "db_confirmation_page", sanitize_text_field( $_POST['db_confirmation_page']) );
 
    } 


 if ( isset( $_POST['db_details_page'] ) ) {
 

        update_option( "db_details_page", sanitize_text_field( $_POST['db_details_page']) );
 
    } 

 if ( isset( $_POST['db_terms_page'] ) ) {
 

        update_option( "db_terms_page", sanitize_text_field( $_POST['db_terms_page']) );
 
    } 

if ( isset( $_POST['db_cancel_page'] ) ) {
 

        update_option( "db_cancel_page", sanitize_text_field( $_POST['db_cancel_page']) );
 
    } 


if ( isset( $_POST['db_site_url'] ) ) {
 

        update_option( "db_site_url", sanitize_text_field( $_POST['db_site_url']) );
 
    } 




  if ( isset( $_POST['db_paypal'] )  )
{

 update_option( "db_paypal_enable", "Yes");

}
else 

{

 update_option( "db_paypal_enable","No");

}



if ( isset( $_POST['db_paypal_api_username'] ) ) {
 

        update_option( "db_paypal_api_username", sanitize_text_field( $_POST['db_paypal_api_username']) );
 
    } 

    if ( isset( $_POST['db_paypal_api_password'] ) ) {
 

        update_option( "db_paypal_api_password", sanitize_text_field( $_POST['db_paypal_api_password']) );
 
    } 

    if ( isset( $_POST['db_paypal_api_signiture'] ) ) {
 

        update_option( "db_paypal_api_signiture", sanitize_text_field( $_POST['db_paypal_api_signiture']) );
 
    } 


  if ( isset( $_POST['db_cod'] )  )
{

 update_option( "db_cod", "Yes");

}
else 

{

 update_option( "db_cod","No");

}



 if ( isset( $_POST['db_cashtitle'] ) ) {
 

        update_option( "db_cashtitle", sanitize_text_field( $_POST['db_cashtitle']) );
 
    } 

     if ( isset( $_POST['db_cash_description'] ) ) {
 

        update_option( "db_cash_description", sanitize_text_field( $_POST['db_cash_description']) );
 
    } 

     if ( isset( $_POST['db_cash_instruction'] ) ) {
 

        update_option( "db_cash_instruction", sanitize_text_field( $_POST['db_cash_instruction']) );
 
    } 



    if ( isset( $_POST['db_paypal_title'] ) ) {
 

        update_option( "db_paypal_title", sanitize_text_field( $_POST['db_paypal_title']) );
 
    } 

        if ( isset( $_POST['db_paypal_description'] ) ) {
 

        update_option( "db_paypal_description", sanitize_text_field( $_POST['db_paypal_description']) );
 
    } 

        if ( isset( $_POST['db_paypal_ID'] ) ) {
 

        update_option( "db_paypal_ID", sanitize_text_field( $_POST['db_paypal_ID']) );
 
    } 


 if ( isset( $_POST['db_url'] ) ) {
 

        update_option( "db_url", sanitize_text_field( $_POST['db_url']) );
 
    } 


 if ( isset( $_POST['db_deposit_policy'] ) ) {
 

        update_option( "db_deposit_policy", sanitize_text_field( $_POST['db_deposit_policy']) );
 
    } 


     if ( isset( $_POST['db_cancel_policy'] ) ) {
 

        update_option( "db_cancel_policy", sanitize_text_field( $_POST['db_cancel_policy']) );
 
    } 


     if ( isset( $_POST['db_refund_policy'] ) ) {
 

        update_option( "db_refund_policy", sanitize_text_field( $_POST['db_refund_policy']) );
 
    } 


 if ( isset( $_POST['db_enabletaxes'] )  )
{

 update_option( "db_enabletaxes", "yes");

}
else 

{

 update_option( "db_enabletaxes","no");

}


 if ( isset( $_POST['db_roundingtaxes'] )  )
{

 update_option( "db_roundingtaxes", "yes");

}
else 

{

 update_option( "db_roundingtaxes","no");

}



 if ( isset( $_POST['db_priceswithtax'] ) ) {
 

        update_option( "db_priceswithtax", sanitize_text_field( $_POST['db_priceswithtax']) );
 
    } 

     if ( isset( $_POST['db_display_prices'] ) ) {
 

        update_option( "db_display_prices", sanitize_text_field( $_POST['db_display_prices']) );
 
    } 



}


?>

 <?php
            
       

$active_tab = isset( $_GET[ 'tab' ] ) ? $_GET[ 'tab' ] : 'general';

$section_tab = isset( $_GET[ 'section' ] ) ? $_GET[ 'section' ] : 'main';

 ?>

      <div id="icon-tools" class="icon32"></div>
      <h2>Dragon Bay Inn Reserve Settings Page</h2>
      <h2 class="nav-tab-wrapper">
      <a href="?page=db_settings&tab=general" class="nav-tab <?php echo $active_tab == 'general' ? 'nav-tab-active' : ''; ?>">General</a>
      <a href="?page=db_settings&tab=checkout" class="nav-tab <?php echo $active_tab == 'checkout' ? 'nav-tab-active' : ''; ?>">Checkout</a>
      <a href="?page=db_settings&tab=tax" class="nav-tab <?php echo $active_tab == 'tax' ? 'nav-tab-active' : ''; ?>">Tax</a>
      </h2>
      </div>


<form method="post" action="">
    <?php settings_fields( 'db-plugin-settings-group' ); ?>
    <?php do_settings_sections( 'db-plugin-settings-group' ); ?>

<?php
         if($active_tab == 'checkout' ) 
{ ?>

  



<a href="?page=db_settings&tab=checkout&section=main" >Checkout</a>

<a href="?page=db_settings&tab=checkout&section=cash" >Cash</a>

<a href="?page=db_settings&tab=checkout&section=paypal" >PayPal</a>
   
<?php
         if($section_tab == 'main' ) 


{    ?>


<h3> Checkout </h3> 

<p>These pages need to be set so that Dragon Bay Inn Reserve knows where to send users when they have completed there reservation.</p>

<table>
<tr> <td>
<label> Reservation page </label></td>
<td>
<select name='db_reservation_page'>
<option value="" >  </option>
<?php

global $post;

$args = array( 'posts_per_page' => -1 , 'post_type' => 'page');

$myposts = get_posts( $args );

foreach ( $myposts as $post ) : setup_postdata( $post ); 





if($post->post_name == get_option('db_reservation_page'))
{

echo '<option value="'.$post->post_name.'"   selected="selected"   >'.get_the_title($post->ID).'</option>';
}
else
{

echo '<option value="'.$post->post_name.'"      >'.get_the_title($post->ID).'</option>';

}

endforeach; 


?>
</select></td></tr>
<tr> <td>
<label> Reservation Details page <label></td>
<td>
<select name='db_details_page'>
<option value="" >  </option>
<?php

global $post;

$args = array( 'posts_per_page' => -1 , 'post_type' => 'page');

$myposts = get_posts( $args );

foreach ( $myposts as $post ) : setup_postdata( $post ); 

if($post->post_name == get_option('db_details_page'))
{

echo '<option value="'.$post->post_name.'"   selected="selected"   >'.get_the_title($post->ID).'</option>';
}
else
{

echo '<option value="'.$post->post_name.'"      >'.get_the_title($post->ID).'</option>';

}


endforeach; 


?>
</select></td> </tr>
<tr> <td>
<label> Confirmation page <label></td>
<td>
<select name='db_confirmation_page'>
<option value="" >  </option>
<?php

global $post;

$args = array( 'posts_per_page' => -1 , 'post_type' => 'page');

$myposts = get_posts( $args );

foreach ( $myposts as $post ) : setup_postdata( $post ); 

if($post->post_name == get_option('db_confirmation_page'))
{

echo '<option value="'.$post->post_name.'"   selected="selected"   >'.get_the_title($post->ID).'</option>';
}
else
{

echo '<option value="'.$post->post_name.'"      >'.get_the_title($post->ID).'</option>';

}
endforeach; 


?>
</select></td> </tr>

<tr> <td>
<label> Thank you page </label></td>
<td>
<select name='db_thankyou_page'>
<option value="" >  </option>
<?php

global $post;

$args = array( 'posts_per_page' => -1 , 'post_type' => 'page');

$myposts = get_posts( $args );

foreach ( $myposts as $post ) : setup_postdata( $post ); 

if($post->post_name == get_option('db_thankyou_page'))
{

echo '<option value="'.$post->post_name.'"   selected="selected"   >'.get_the_title($post->ID).'</option>';
}
else
{

echo '<option value="'.$post->post_name.'"      >'.get_the_title($post->ID).'</option>';

}
endforeach; 


?>
</select></td></tr>
<tr> <td>
<label> Reservation Cancellation page <label></td>
<td>
<select name='db_cancel_page'>
<option value="" >  </option>
<?php

global $post;

$args = array( 'posts_per_page' => -1 , 'post_type' => 'page');

$myposts = get_posts( $args );

foreach ( $myposts as $post ) : setup_postdata( $post ); 

if($post->post_name == get_option('db_cancel_page'))
{  

echo '<option value="'.$post->post_name.'"   selected="selected"   >'.get_the_title($post->ID).'</option>';
}
else
{

echo '<option value="'.$post->post_name.'"      >'.get_the_title($post->ID).'</option>';

}


endforeach; 


?>
</select></td> </tr>
<tr> <td>
<label> Terms and Conditions <label></td>
<td>
<select name='db_terms_page'>
<option value="" >  </option>
<?php

global $post;

$args = array( 'posts_per_page' => -1 , 'post_type' => 'page');

$myposts = get_posts( $args );

foreach ( $myposts as $post ) : setup_postdata( $post ); 

if($post->post_name == get_option('db_terms_page'))
{

echo '<option value="'.$post->post_name.'"   selected="selected"   >'.get_the_title($post->ID).'</option>';
}
else
{

echo '<option value="'.$post->post_name.'"      >'.get_the_title($post->ID).'</option>';

}

endforeach; 


?>

</select></td> </tr>

</table>
</br>


<h3> Payment Gateways </h3> 

<table  class="payment_gateway_table" >

<tr> <th> Gateway </h3> </th> <th>Gateway ID  </th> <th> Enabled </th> </tr>

<?php


if(get_option('db_paypal_enable') == 'Yes')

{

$api = get_option('db_paypal_api_username') ; 

$password = get_option('db_paypal_api_password');

$signiture = get_option('db_paypal_api_signiture');


echo "<tr> <td>  <h3><a href='?page=db_settings&tab=checkout&section=paypal' >PayPal</a> </h3> </td> <td> </td> <td> </td> </tr>

<tr> <td> API Username </td> <td> API Password </td> <td> API Signature </td> </tr>


<tr> <td> $api </td> <td> $password </td> <td> $signiture </td> </tr> ";


}



?>

<?php


if(get_option('db_cod') == 'Yes')

{

$title = get_option('db_cashtitle') ; 

$description = get_option('db_cash_description');

$instructions = get_option('db_cash_instruction');


echo "<tr> <td>  <h3><a href='?page=db_settings&tab=checkout&section=cash' >  Cash </a>  </h3> </td> <td> </td> <td> </td> </tr>


<tr> <td> Title </td> <td> Description </td> <td> Instructions </td> </tr>


<tr> <td> $api </td> <td> $password </td> <td> $signiture </td> </tr> ";


}



?>







</table>

<?php


}
        else if( $section_tab == 'cash' ) {    ?>



<h3> Cash on Delivery </h3> 

<p>Have your customers pay with cash (or by other means) upon delivery.</p>



<table>


<tr> <td>
<label> Enable COD<label></td>
<td>


<input type="checkbox" name="db_cod" value="yes" <?php if(get_option('db_cod') == 'Yes'){echo 'checked';} ?>>Enable Cash On Delivery<br>




</td> </tr>


<tr> <td>
<label> Title <label></td>
<td>


<input type="text" size ="50" name="db_cashtitle" value="<?php $db_cashtitle = get_option('db_cashtitle'); echo $db_cashtitle ; ?>">



</td> </tr>

<tr> <td>
<label> Description <label></td>
<td>

<textarea rows="4" cols="50" name="db_cash_description" value="<?php $db_cash_description = get_option('db_cash_description'); echo 
$db_cash_description;; ?>" ></textarea>

</td> </tr>


<tr> <td>

<label> Instructions <label></td>

<td>

<textarea rows="4" cols="50" name="db_cash_instruction" value="<?php $db_cash_instruction = get_option('db_cash_instruction'); echo $db_cash_instruction; ?>"></textarea>

</td> </tr>


</table>


<?php


} else if( $section_tab == 'paypal' ) {    ?>



<h3> PayPal </h3> 

<p>PayPal standard sends customers to PayPal to enter their payment information.</p>



<table>


<tr> <td>
<label> Enable PayPal<label></td>
<td>


<input type="checkbox" name="db_paypal" value="yes"  <?php if(get_option('db_paypal_enable') == 'Yes'){echo 'checked';} ?> >Enable PayPal<br>




</td> </tr>


<tr> <td>
<label> Title <label></td>
<td>


<input type="text" size ="50" name="db_paypal_title" value="<?php $db_paypal_title = get_option('db_paypal_title'); echo $db_paypal_title ; ?>">



</td> </tr>

<tr> <td>
<label> Description <label></td>
<td>

<textarea rows="4" cols="50" name="db_paypal_description" value="<?php $db_paypal_description = get_option('db_paypal_description'); echo $db_paypal_description ; ?>" > </textarea>

</td> </tr>


<tr> <td>

<label> PayPal Merchant ID <label></td>

<td>

<input type="text" size ="50" name="db_paypal_ID"  value="<?php $db_paypal_ID = get_option('db_paypal_ID'); echo $db_paypal_ID ; ?>" >

</td> </tr>


</table>



<h3> API Credentials</h3> 

<p>Enter your PayPal API credentials to process refunds via PayPal. Learn how to access your PayPal API Credentials here.</p>


<table>

<tr> <td>

<label> API Username <label></td>

<td>

<input type="text" size ="50" name="db_paypal_api_username" value="<?php  $username = get_option('db_paypal_api_username'); echo $username; ?>" >

</td> </tr>

<tr> <td>

<label> API Password <label></td>

<td>

<input type="text" size ="50" name="db_paypal_api_password" value="<?php  $password = get_option('db_paypal_api_password'); echo $password; ?>" >

</td> </tr>


<tr> <td>

<label> API Signature <label></td>

<td>

<input type="text" size ="50" name="db_paypal_api_signiture" value="<?php  $signiture = get_option('db_paypal_api_signiture'); echo $signiture; ?>" >

</td> </tr>





</table>



<?php


}


?>






<?php


}
        else if( $active_tab == 'general' ) { ?>


<h3> General settings </h3>


<table>

<tr> <td>

<label> Your website url <label></td>

<td>

<input type="text" size ="50" name="db_url" value="<?php $db_url = get_option('db_url'); echo $db_url;  ?>">

</td> </tr>


</table>

<h3> Your deposit policy</h3> 

<textarea rows="4" cols="50" name="db_deposit_policy" > <?php $db_deposit_policy = get_option('db_deposit_policy'); echo $db_deposit_policy ; ?> </textarea>

<h3> Your cancellation policy </h3> 

<textarea rows="4" cols="50" name="db_cancel_policy" ><?php $db_cancel_policy = get_option('db_cancel_policy'); echo $db_cancel_policy ; ?> </textarea>

<h3> Your refund policy</h3> 

<textarea rows="4" cols="50" name="db_refund_policy"  ><?php $db_refund_policy = get_option('db_refund_policy'); echo $db_refund_policy ; ?> </textarea>





<h3> Currency Options </h3> 

<p>The following options affect how prices are displayed on the frontend.
</p>

<table>
<tr> <td>
<label> Currency <label></td>
<td>
<select name='db_curreny'>
<?php

global $post;

$args = array( 'posts_per_page' => -1 , 'post_type' => 'page');

$myposts = get_posts( $args );

foreach ( $myposts as $post ) : setup_postdata( $post ); 

echo '<option value="'.$post->post_name.'">'.get_the_title($post->ID).'</option>';
endforeach; 



?>

</select></td> </tr></table>


<?php


} else if( $active_tab == 'tax' ) { ?>


<table>


<tr> <td>
<label> Enable Taxes <label></td>
<td>


<input type="checkbox" name="db_enabletaxes" value="yes" <?php if(get_option('db_enabletaxes') == 'yes'){echo 'checked';} ?>>Enable taxes and tax calculations<br>




</td> </tr>


<tr> <td>
<label> Prices Entered With Tax  <label></td>
<td>


<input type="radio" name="db_priceswithtax" value="inclusive" <?php if(get_option('db_priceswithtax') == 'inclusive'){echo 'checked';} ?> >Yes, I will enter prices inclusive of tax<br>

<input type="radio" name="db_priceswithtax" value="exclusive" <?php if(get_option('db_priceswithtax') == 'exclusive'){echo 'checked';} ?> >No, I will enter prices exclusive of tax


</td> </tr>

<tr> <td>
<label> Rounding <label></td>
<td>

<input type="checkbox" name="db_roundingtaxes" value="yes" <?php if(get_option('db_roundingtaxes') == 'yes'){echo 'checked';} ?>>Round tax at subtotal level, instead of rounding per line
<br>


</td> </tr>


<tr> <td>

<label> Display Prices <label></td>

<td>

<select name='db_display_prices'>


<option value='excluding'  >  Excluding Taxes</option>

<option value='including'  >  Including Taxes</option>


</select>  </td> </tr>


<tr> <td>
<label> Display Prices During Checkout <label></td>
<td>

<select name='db_display_prices_checkout'>

<option value="" >  </option>


<option value='excluding' <?php

if(get_option('db_display_prices_checkout') == 'excluding' )
{

echo "selected";

}



?>


 >  Excluding Taxes</option>

<option value='including'  



<?php

if(get_option('db_display_prices_checkout') == 'including' )
{

echo "selected";

}



?>



>  Including Taxes</option>



?>
</select>

</td> </tr>









</table>


<?php


}


?>

<input type="hidden" name='form_submitted' value ='Submit' />

    <?php submit_button(); ?>

</form>

<?php


}



}


?>
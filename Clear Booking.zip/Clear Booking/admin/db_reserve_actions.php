<?php


class db_reserve_actions

{
  


 public static function db_reserve_actions_()
  

  {
    

     add_action( 'wp_ajax_rooms', array( __CLASS__, 'rooms_action' ) );
     add_action( 'wp_ajax_nopriv_rooms', array( __CLASS__, 'rooms_action' ) );



  }





function rooms_action() {

   ob_clean();

  
   $cont = array();

   echo json_encode($cont);

   wp_die();


}





}


?>
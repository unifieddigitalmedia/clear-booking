<?php


class db_reserve_shortcode

{
     
 function init() 


       {



		add_shortcode('db_reserve', array(__CLASS__, 'db_reserve_shortcode_'));



	}


function db_reserve_shortcode_($atts) {


      
    ob_start();

    


     

    ?>

 









<form action="../<?php $reservation_page = get_option('db_reservation_page'); echo $reservation_page;  ?>/" method="post" id="shortcodeform" class="shortcodeform" name="shortcodeform">
 
<div class="row" >

<div class="col-sm-3" id='bookinglabel' ><h3> Reserve online </label> </div><div class="col-sm-9" ></h3> </div>

</div>

<div class="row" ng-hide='availabilty'>

<div class="col-sm-3" id='checkavaiabiltyrow' >

<div class="form-group has-success has-feedback">

<select id="travellers" class="form-control" name='room' ng-model='travellers'>

<option >SELECT A SUITE</option>


</select>  


</div> 



</div>



<div class="col-sm-2" id='checkavaiabiltyrow' >

<div class="form-group has-success has-feedback">

<input type="text" class="form-control"  id="fromdate" name="from" > 

<span class="glyphicon glyphicon-th form-control-feedback"></span> 

</input> 

</div>

</div>

<div class="col-sm-2" id='checkavaiabiltyrow' >

<div class="form-group has-success has-feedback">

<input type="text" class="form-control" id="todate"  name="to"> 

<span class="glyphicon glyphicon-th form-control-feedback"></span>  

</input> 

</div>

</div>

<script type="text/javascript">

           
        </script>  

<div class="col-sm-2" id='checkavaiabiltyrow' >

<div class="form-group has-success has-feedback">

<input id="promo" class="form-control" type="text" placeholder="PROMO CODE" name='promo' /> 

<span class="glyphicon glyphicon-qrcode form-control-feedback"></span>

</div>

</div>

<div class="col-sm-3" id='checkavaiabiltyrow' >

<button class="btn btn-default btn-block" type="button"  id="checkavailability">CHECK AVAILABILITY</button> 

</div>

</div>

</div>

<div id='errormessage' class='checking'> <p id="error">  </p> </div>

<div class="row" id='calenderrow'>
<div class="col-sm-6" id="frommonth">

</div>

<div class="col-sm-6" id="tomonth">

</div>


</div>

</form>


 <?php 

   

    return ob_get_clean();




    }



	








}






?>
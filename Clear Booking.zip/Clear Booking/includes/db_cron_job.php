<?php

   $path = $_SERVER['DOCUMENT_ROOT'];

   include_once $path . '/wp-config.php';

   include_once $path . '/wp-load.php';

   include_once $path . '/wp-includes/wp-db.php';

   include_once $path . '/wp-includes/pluggable.php';

   include_once $path . '/wp-includes/http.php';

global $wpdb;

$table_name = $wpdb->prefix . 'db_reservations';

$reses = $wpdb->get_results("SELECT * FROM $table_name " );


foreach ( $reses as $res ) 


{

$value =  $res->fromdate ;

$month = substr("$value",5,2);

$day =  substr("$value",8,2);

$todaysdate = date('Y-m-d');



if(($month <= 12 && $day <= 14 ) || ( $month >= 4 &&  $day >= 20  ) )
{


$timeperiod = date('Y-m-d', strtotime('-21 days'));

$deadline = date('Y-m-d', strtotime('-14 days'));

if($todaysdate >= $timeperiod && $res->balance <> 0)

{

$days = caldifference($deadline,$todaysdate);

if($days > 0)
{
 depositReminder($res->resid,$days);

}
else 

{

  depositforfeited($rid,$days);


}
 

}



}
else if(($month <= 4 && $day <= 19 ) || ( $month >= 1 &&  $day >= 1  ))

{

$timeperiod = date('Y-m-d', strtotime('-37 days'));



$deadline = date('Y-m-d', strtotime('-30 days'));




if(($todaysdate >= $timeperiod) && $res->balance <> 0)

{



$days = caldifference($deadline,$todaysdate);

if($days > 0)
{
 depositReminder($res->resid,$days);

}
else 

{

  depositforfeited($rid,$days);


}
 

}



}

else if($month == 12 && ($day <= 31 || $day >= 14  ))

{


    $timeperiod = date('Y-m-d', strtotime('-67 days'));
 
    $deadline = date('Y-m-d', strtotime('-60 days'));

if($todaysdate >= $timeperiod && $res->balance <> 0)

{

$days = caldifference($deadline,$todaysdate);

if($days > 0)
{
 depositReminder($res->resid,$days);

}
else 

{

  depositforfeited($rid,$days);


}
 



}



}


}


function depositforfeited($rid,$days)

{


global $wpdb;

$table_name = $wpdb->prefix . 'db_reservations';


$res_ID = $wpdb->get_row( "SELECT * FROM $table_name WHERE resid = '$rid' " );

$value =  $res_ID->fromdate ;

$day =  substr("$value",8,2);

$month = substr("$value",5,2);

$year =  substr("$value",0,4);


$jd=gregoriantojd($month,$day,$year);

$monthName = date('F', mktime(0, 0, 0,$month, 10)); 

$date = jddayofweek($jd,1).' , '. $monthName .' '. $day .' '. $year;


$to = $res_ID->email;

$subject = "Dragon Bay Inn Booking Reminder";

$message = "

<html>

<head>

<title>Dragon Bay Inn ... not just a villa </title>

</head>

<body>

<table>

<tr> <td colspan='4'></td> </tr>

<tr> <td colspan='4'> <p> NAME: $res_ID->firstname  $res_ID->lastname</p> </td></tr>

<tr> <td colspan='2'> <p> DAY & DATE OF ARRIVAL: $date </p></td> <td colspan='2'> NO. OF NIGHTS: $res_ID->lengthofstay </td>  </tr>

<tr> <td> <p> ROOM(S):</p></td> <td> <p> $user_count  </p></td> <td colspan='2'> </td> </tr>

<tr> <td colspan='4'> <p> Please check that the above room(s) and date(s) are correct. We acknowledge receipt of a deposit on the above </p> </td></tr>

<tr> <td colspan='4'> <p>rooms of $res_ID->deposit. </p> </td></tr>

<tr> <td colspan='4'> <p> Our cancellation policy permits a 50% rebate of the deposit, only if more than 7 days' notice is given.</p> </td></tr>

<tr> <td colspan='4'> <p>The full amount of the stay and any deposit paid is non-refundable when inside 14 days, 30 days for Easter and 60 days during Christmas and New Year. </p> </td></tr>

<tr> <td colspan='4'> <p> No refund and full amount of stay is forfeited when there is a no-show. As you have not paaid you outstanding balance of $res_ID->balance your deposit has been forfeited.  </p> </td></tr>

<tr> <td colspan='4'> <p> Sincerely,</p> </td> </tr>

<tr> <td> </td> </tr>

<tr> <td colspan='4'> <p>Dragon Bay Inn </p></td> </tr>

<tr> <td colspan='4'> </td> </tr>

<tr> <td colspan='4'> <p>Phone:</p> </td> </tr>

<tr> </tr>


</table>

</body>

</html>
";



$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
$headers .= 'From: <machel.slack@unifieddigitalmedia.co.uk>' . "\r\n";
$headers .= 'Cc: beverley.a.bryan@gmail.com,machel.slack@unifieddigitalmedia.co.uk' . "\r\n";

mail($to,$subject,$message,$headers);




}

function depositReminder($rid,$days)

{


global $wpdb;

$table_name = $wpdb->prefix . 'db_reservations';


$res_ID = $wpdb->get_row( "SELECT * FROM $table_name WHERE resid = '$rid' " );

$value =  $res_ID->fromdate ;

$day =  substr("$value",8,2);

$month = substr("$value",5,2);

$year =  substr("$value",0,4);


$jd=gregoriantojd($month,$day,$year);

$monthName = date('F', mktime(0, 0, 0,$month, 10)); 

$date = jddayofweek($jd,1).' , '. $monthName .' '. $day .' '. $year;


$to = $res_ID->email;

$subject = "Dragon Bay Inn Booking Reminder";

$message = "

<html>

<head>

<title>Dragon Bay Inn ... not just a villa </title>

</head>

<body>

<table>

<tr> <td colspan='4'></td> </tr>

<tr> <td colspan='4'> <p> NAME: $res_ID->firstname  $res_ID->lastname</p> </td></tr>

<tr> <td colspan='2'> <p> DAY & DATE OF ARRIVAL: $date </p></td> <td colspan='2'> NO. OF NIGHTS: $res_ID->lengthofstay </td>  </tr>

<tr> <td> <p> ROOM(S):</p></td> <td> <p> $user_count  </p></td> <td colspan='2'> </td> </tr>

<tr> <td colspan='4'> <p> Please check that the above room(s) and date(s) are correct. We acknowledge receipt of a deposit on the above </p> </td></tr>

<tr> <td colspan='4'> <p>rooms of $res_ID->deposit. The balance of $res_ID->balance is due within the next $days days. </p> </td></tr>

<tr> <td colspan='4'> <p> Our cancellation policy permits a 50% rebate of the deposit, only if more than 7 days' notice is given.</p> </td></tr>

<tr> <td colspan='4'> <p>The full amount of the stay and any deposit paid is non-refundable when inside 14 days, 30 days for Easter and 60 days during Christmas and New Year. </p> </td></tr>

<tr> <td colspan='4'> <p> No refund and full amount of stay is forfeited when there is a no-show. </p> </td></tr>

<tr> <td colspan='4'> <p> Sincerely,</p> </td> </tr>

<tr> <td> </td> </tr>

<tr> <td colspan='4'> <p>Dragon Bay Inn </p></td> </tr>

<tr> <td colspan='4'> </td> </tr>

<tr> <td colspan='4'> <p>Phone:</p> </td> </tr>

<tr> </tr>


</table>

</body>

</html>
";



$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
$headers .= 'From: <machel.slack@unifieddigitalmedia.co.uk>' . "\r\n";
$headers .= 'Cc: beverley.a.bryan@gmail.com,machel.slack@unifieddigitalmedia.co.uk' . "\r\n";

mail($to,$subject,$message,$headers);



}

function caldifference ($deadline,$today) {


   $diff = abs(strtotime($deadline) - strtotime($today));

   $years = floor($diff / (365*60*60*24));

   $months = floor(($diff - $years * 365*60*60*24) / (30*60*60*24));

   $days = floor(($diff - $years * 365*60*60*24 - $months*30*60*60*24)/ (60*60*24));


   return $days;

}

?>
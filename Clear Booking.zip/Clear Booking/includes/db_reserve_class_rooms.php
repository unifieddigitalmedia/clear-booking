<?php


class db_reserve_class_rooms 

{
  


 
 public static function db_reserve_class_rooms_()
  

  {


      add_action( 'wp_ajax_rooms', array( __CLASS__, 'rooms_action' ) );
      add_action( 'wp_ajax_nopriv_rooms', array( __CLASS__, 'rooms_action' ) );


  }



public function rooms_action() {


   $cont = array();

   ob_clean();

   global $wpdb;

   $date = str_replace('/', '-', $_REQUEST[from]);

   $from = date('Y-m-d', strtotime($date));



   $date1 = str_replace('/', '-', $_REQUEST[to]);

   $to = date('Y-m-d', strtotime($date1));

   $table_name = $wpdb->prefix . 'db_bookings';

   $cont = $wpdb->get_results( "SELECT rid FROM $table_name WHERE ('$from' BETWEEN `fromdate` AND `todate`) AND  ('$to' BETWEEN `fromdate` AND `todate`) AND status = 'R' " );
   
   $table_name1 = $wpdb->prefix . 'db_rooms';

   if(sizeof($cont) == 0)

   { 


    

     $cont = $wpdb->get_results( "SELECT * FROM $table_name1" ); 

   
   

   } else 

   { 


$cont = $wpdb->get_results( "SELECT * FROM $table_name1 WHERE rid NOT IN (SELECT rid FROM $table_name WHERE ('$from' BETWEEN `fromdate` AND `todate`) AND  ('$to' BETWEEN `fromdate` AND `todate`) AND status = 'R' )" ); 


   }
   

foreach ( $cont as $con ) 


{


         $html .='

         <div id="firstinnerrow" >
         <div class="row" >
         <div class="col-sm-10">'.$con->name.'</div>
         <div class="col-sm-2"></div>
         </div>

         <div class="row" id="innerfirstinnerrow">
         <div class="col-sm-10">'.$con->description.'</div>
         <div class="col-sm-2">
         <p id="roombtn" type="button" value="'.$con->rid.'">ADD</p>
         </div>

         </div>
         </div>';



}





   echo $html;

   wp_die();


}





}


?>
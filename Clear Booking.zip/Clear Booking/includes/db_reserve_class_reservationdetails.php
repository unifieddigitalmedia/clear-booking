
<?php


header("Access-Control-Allow-Origin: *");

header("Content-Type: application/json; charset=UTF-8");

class db_reserve_class_reservationdetails 

{
 


 
 public static function db_reserve_class_reservationdetails_()
  

  {


      add_action( 'wp_ajax_reservationdetails', array( __CLASS__, 'reservationdetails' ) );

      add_action( 'wp_ajax_nopriv_reservationdetails', array( __CLASS__, 'reservationdetails' ) );


  }


public function reservationdetails() {

   ob_clean();

   global $wpdb;

   $table_name = $wpdb->prefix . 'db_reservations';
   
   $resID = $wpdb->get_row( "SELECT * FROM $table_name WHERE resid = '$_REQUEST[resID]' " );

   $html .= '<div class="row" >
  
             <div class="col-sm-6">  

             <div class="row" >

             <div class="col-sm-12" >

             <h4>'.$resID->fromdate.'-'.$resID->todate.'</h4>

             </div>

             </div>';


$table_name = $wpdb->prefix . 'db_bookings';

$rms_results = $wpdb->get_results( "SELECT rid FROM $table_name WHERE resid = '$_REQUEST[resID]' " );

foreach ( $rms_results as $rms_result ) 
{

$table_name = $wpdb->prefix . 'db_rooms';

$rms = $wpdb->get_row( "SELECT * FROM $table_name WHERE rid = '$rms_result->rid' " );


$html    .= '<div class="row" >

             <div class="col-sm-6">'.

             $rms->description

             .'</div>

             <div class="col-sm-3" >

             '.$resID->lengthofstay.'days @'.$rms->price.'per night

             </div>

             <div class="col-sm-3" >

             '.$rms->price*$resID->lengthofstay.'

             </div>

             </div>';

}


$html    .= '<h4>Personal Details </h4>

             <div class="row"  >

             <div class="col-sm-6">

             First Name :

             </div>

             <div class="col-sm-6">'.

             $resID->firstname

             .'</div>

             </div>';

$html    .= '<div class="row"  >

             <div class="col-sm-6">

             Last Name :

             </div>

             <div class="col-sm-6">'.

             $resID->lastname

             .'</div>

             </div>';

$html    .= '<div class="row"  >

             <div class="col-sm-6">

             Phone :

             </div>

             <div class="col-sm-6">'.

             $resID->phone 

             .'</div>

             </div>';

$html    .= '<div class="row"  >

             <div class="col-sm-6">

             Email :

             </div>

             <div class="col-sm-6">'.

             $resID->email

             .'</div>

             </div>';

$html    .= ' <h4>Dependents </h4>

              <div class="row" >

              <div class="col-sm-6" >

              Adults :

              </div>

              <div class="col-sm-6">'.

              $resID->adults

              .'</div>

              

              </div>';


$html    .= ' 
              <div class="row" >

              <div class="col-sm-6" >

              Children :

              </div>

              <div class="col-sm-6">'.

              $resID->children

              .'</div>

              

              </div>';


$html    .= ' 

              <div class="row" >

              <div class="col-sm-6" >

              Infants :

              </div>

              <div class="col-sm-6">'.

              $resID->infants

              .'</div>

              

              </div>';

$table_name = $wpdb->prefix . 'db_reservation_coupons';

$cpnsID = $wpdb->get_results( "SELECT * FROM $table_name WHERE resid = '$_REQUEST[resID]' " );

$total = $resID->total;

foreach ( $cpnsID as $cpnID ) 

{

$table_name = $wpdb->prefix . 'db_coupons';

$cpnsDes = $wpdb->get_row( "SELECT * FROM $table_name WHERE cid = '$cpnID->cid' " );

$html    .= '<div class="row">

             <div class="col-sm-6">'.

             $cpnsDes->name

             .'</div>

             <div class="col-sm-3">

             <p> USD </p>

             </div>

             <div class="col-sm-3" >('.

             (($total * $cpnsDes->amount)/100).')

             </div>

             </div>';

$total = $total - (($total * $cpnsDes->amount)/100);

}

$html    .= '<div class="row" >
             <div class="col-sm-6">

             <p>  Tax </p>
             </div>

             <div class="col-sm-3">

             <p> USD </p>

             </div>

             <div class="col-sm-3">

             <p>  </p>

             </div>

             </div>


             <div class="row" >
             <div class="col-sm-6" >

             <h4> TOTAL</h4> 

             </div>
             <div class="col-sm-3">

             <p> USD </p>

             </div>

             <div class="col-sm-3" >

             <p>'. $resID->total .'</p>

             </div>

             </div>';

$html    .= '</div>

             <div class="col-sm-6">  </div>

             </div>';

  

   echo $html;

   wp_die();


}





}


?>
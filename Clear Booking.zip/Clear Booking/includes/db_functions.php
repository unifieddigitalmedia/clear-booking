<?php


 $path = $_SERVER['DOCUMENT_ROOT'];

   include_once $path . '/wp-config.php';

   include_once $path . '/wp-load.php';

   include_once $path . '/wp-includes/wp-db.php';

   include_once $path . '/wp-includes/pluggable.php';

   include_once $path . '/wp-includes/http.php';

   global $wpdb;


function cal_amt_to_pay($resID,$deposit) {



global $wpdb;

$table_name = $wpdb->prefix . 'db_reservations';

$res = $wpdb->get_row("SELECT * FROM $table_name WHERE resid = '$resID' " );

$value =  $res->fromdate ;

$month = substr("$value",5,2);

$day =  substr("$value",8,2);

$todaysdate = date('Y-m-d');

$d_policy = get_option('db_deposit_policy');


 

    
    $arrivalDate =date('Y-m-d', strtotime($res->fromdate));;
    
   
    $RegularBegin = date('Y-m-d', strtotime("04/20/2016"));
    $RegularEnd = date('Y-m-d', strtotime("12/14/2016"));


    $HighBegin = date('Y-m-d', strtotime("01/01/2016"));
    $HighEnd = date('Y-m-d', strtotime("04/19/2016"));

    $SecondHighBegin = date('Y-m-d', strtotime("12/15/2016"));
    $SecondHighEnd = date('Y-m-d', strtotime("12/31/2016"));



if(($arrivalDate > $RegularBegin) && ($arrivalDate < $RegularEnd) )

{



$timeperiod = date('Y-m-d', strtotime('-21 days'));

$deadline = date('Y-m-d', strtotime('-14 days'));

if($todaysdate >= $timeperiod )

{

$days = caldifference($deadline,$todaysdate);


 if($days > 0)
{

$deposit_policy = $deposit.' USD '.$d_policy;


return $deposit_policy;


}
else 

{

$deposit_policy = $res->total.' USD will need to be paid to keep this booking as stated in our policy below';

return $deposit_policy;


}
 


}



}
else if(($arrivalDate > $HighBegin) && ($arrivalDate < $HighEnd) )

{


$timeperiod = date('Y-m-d', strtotime('-37 days'));



$deadline = date('Y-m-d', strtotime('-30 days'));




if(($todaysdate >= $timeperiod))

{


$days = caldifference($deadline,$todaysdate);


 if($days > 0)

{

$deposit_policy = $deposit.' USD '.$d_policy;


return $deposit_policy;


}
else 

{

$deposit_policy = $res->total.' USD will need to be paid to keep this booking as stated in our policy below';

return $deposit_policy;


}
 
 


}



}

else if(($arrivalDate > $SecondHighBegin) && ($arrivalDate < $SecondHighEnd))

{


    $timeperiod = date('Y-m-d', strtotime('-67 days'));
 
    $deadline = date('Y-m-d', strtotime('-60 days'));

if($todaysdate >= $timeperiod)

{

$days = caldifference($deadline,$todaysdate);

if($days > 0)
{

$deposit_policy = $deposit.' USD '.$d_policy;


return $deposit_policy;


}
else 

{

$deposit_policy = $res->total.' USD will need to be paid to keep this booking as stated in our policy below';

return $deposit_policy;


}
 



}



}




}

function caldifference ($deadline,$today) {


   $diff = abs(strtotime($deadline) - strtotime($today));

   $years = floor($diff / (365*60*60*24));

   $months = floor(($diff - $years * 365*60*60*24) / (30*60*60*24));

   $days = floor(($diff - $years * 365*60*60*24 - $months*30*60*60*24)/ (60*60*24));


   return $days;

}


function cal_deposit($resID) {


global $wpdb;

$table_name = $wpdb->prefix . 'db_reservations';

$res = $wpdb->get_row("SELECT * FROM $table_name WHERE resid = '$resID' " );

$value =  $res->fromdate ;

$month = substr("$value",5,2);

$day =  substr("$value",8,2);

$todaysdate = date('Y-m-d');

$d_policy = get_option('db_deposit_policy');


 

    
    $arrivalDate =date('Y-m-d', strtotime($res->fromdate));;
    
   
    $RegularBegin = date('Y-m-d', strtotime("04/20/2016"));
    $RegularEnd = date('Y-m-d', strtotime("12/14/2016"));


    $HighBegin = date('Y-m-d', strtotime("01/01/2016"));
    $HighEnd = date('Y-m-d', strtotime("04/19/2016"));

    $SecondHighBegin = date('Y-m-d', strtotime("12/15/2016"));
    $SecondHighEnd = date('Y-m-d', strtotime("12/31/2016"));



if(($arrivalDate > $RegularBegin) && ($arrivalDate < $RegularEnd) )

{


$table_name = $wpdb->prefix . 'db_bookings';

$deposit = 0;

$rooms = $wpdb->get_results( "SELECT rid FROM $table_name WHERE resid = '$_REQUEST[reservationID]'");

$table_name = $wpdb->prefix . 'db_rooms';

foreach ( $rooms as $room ) 

{

$room_price = $wpdb->get_row( "SELECT price FROM $table_name WHERE rid = '$room->rid'");


$deposit = $deposit + $room_price->price;


}


return $deposit;

}
else if(($arrivalDate > $HighBegin) && ($arrivalDate < $HighEnd)) {



return $res->total;

}

else if(($arrivalDate > $SecondHighBegin) && ($arrivalDate < $SecondHighEnd)) {


return $res->total;

}




}
?>
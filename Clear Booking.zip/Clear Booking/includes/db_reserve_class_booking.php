<?php




class db_reserve_class_booking 

{
  


 
 public static function db_reserve_class_booking_()
  

  {


      add_action( 'wp_ajax_bkng', array( __CLASS__, 'rooms_action' ) );
      add_action( 'wp_ajax_nopriv_bkng', array( __CLASS__, 'rooms_action' ) );


  }



public function rooms_action() {


   $cont = array();

   $outercont = array();

   ob_clean();

   global $wpdb;

   $table_name = $wpdb->prefix . 'db_rooms';


foreach ($_REQUEST[bkng] as $value)

{


$cont = $wpdb->get_row( "SELECT * FROM $table_name WHERE rid = '$value[id]' " ); 



 $html .= '<div id="firstinnerrow"> <div class="row" >

<div class="col-sm-2">

<p>'. $cont->name .' </p>

</div>
<div class="col-sm-2">

<p>'. $cont->occupancy .'</p>

</div>
<div class="col-sm-2">

<p> 


<select  class="form-control" name="adults" >


<option value="1">1</option>
<option value="2">2</option>

</select> 


</p>

</div>
<div class="col-sm-2">

<p> 

<select  class="form-control" name="children" >

<option value="0">0</option>
<option value="1">1</option>
<option value="2">2</option>


</select> 


</p>

</div>
<div class="col-sm-2">

<p> 

<select  class="form-control" name="infants" >

<option value="0">0</option>
<option value="1">1</option>
<option value="2">2</option>


</select>  


</p>

</div>

<div class="col-sm-2">

<p class="bkngrmrmv" data-id="'.$cont->rid.'">REMOVE </p> 

</div>


</div></div>';



}
   //$cont = json_decode($_REQUEST[bkng],true);

    

   //$html .= '<div class="row" >';



   array_push($outercont,$html);



   $table_name = $wpdb->prefix . 'db_coupons';


foreach ($_REQUEST[bkngcpn] as $cpnval)

{


$cpnt = $wpdb->get_row( "SELECT * FROM $table_name WHERE cid = '$cpnval[id]' " ); 


$cpthtml .= '<div id="firstinnerrow"><div class="row" >

          <div class="col-sm-10">

          <p>'. $cpnt->name .' </p>

          </div>

          <div class="col-sm-2">

          <p> </p>

          </div>

          </div>

          <div class="row" >

          <div class="col-sm-10">

          <p> '.$cpnt->description.' </p>

          </div>
          <div class="col-sm-2">

          <p class="cptrmrmv" data-id="'.$cpnt->cid.'">REMOVE </p> 

          </div>

          </div></div>



';



}


   array_push($outercont,$cpthtml);


$table_name = $wpdb->prefix . 'db_add_ons';


$addOns = $wpdb->get_results( "SELECT * FROM $table_name  " ); 


foreach ( $addOns as $addOn ) 


{

     
$addonhtml .= '

 </br>

  <div id="firstinnerrow">

  <div class="row" >

  <div class="col-sm-6" >

  Would you like '.$addOn->name.'

  </div>
  
  <div class="col-sm-6" >

  <p>  </p>

  </div>


  </div>
  
 
  <div class="row" >

  <div class="col-sm-4" >

  <div class="row" >
  
  <div class="col-sm-6"> <label><input type="radio" name="'.$addOn->name.'"  value="yes" class="radioaddon" data-id="'.$addOn->aid.'">&nbsp;Yes&nbsp;</label></div>
  
  <div class="col-sm-6"> <label><input type="radio" name="'.$addOn->name.'"  value="no" class="radioaddon" >&nbsp;No&nbsp;</label></div>

   </div>

   </div>
  
   <div class="col-sm-8">

   <p>  </p>

   </div>

   </div>
   </div>


';

}


array_push($outercont,$addonhtml);

   echo json_encode($outercont);

   wp_die();


}





}


?>
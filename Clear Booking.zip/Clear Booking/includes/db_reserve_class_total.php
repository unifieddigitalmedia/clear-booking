<?php


header("Access-Control-Allow-Origin: *");

header("Content-Type: application/json; charset=UTF-8");

class db_reserve_class_total 

{
  


 
 public static function db_reserve_class_total_()
  

  {


      add_action( 'wp_ajax_bkngtlt', array( __CLASS__, 'total_action' ) );
      add_action( 'wp_ajax_nopriv_bkngtlt', array( __CLASS__, 'total_action' ) );


  }


public function check_booking($para,$para1) {

foreach ($para as $rmvalue )


{


for ($x  = 0; $x < $para1.length; $x ++  )


{


if( $para1[$x] === $rmvalue )

{


return true;


}




}



}

return true;


}


public function total_action() {


   $cont = array();

   $rmcont = array();

   $rm_found = true;

   ob_clean();

   global $wpdb;


   $date = str_replace('/', '-',$_REQUEST[from]);

   $from = date('Y-m-d', strtotime($date));



   $date1 = str_replace('/', '-',$_REQUEST[to]);

   $to = date('Y-m-d', strtotime($date1));



   $diff = abs(strtotime($to) - strtotime($from));

   $years = floor($diff / (365*60*60*24));

   $months = floor(($diff - $years * 365*60*60*24) / (30*60*60*24));

   $days = floor(($diff - $years * 365*60*60*24 - $months*30*60*60*24)/ (60*60*24));

   $timeheld = date("Y-m-d h:s:i");

   $table_name = $wpdb->prefix . 'db_bookings';

   $cont = $wpdb->get_results( "SELECT rid FROM $table_name WHERE ('$from' BETWEEN `from` AND `to`) AND  ('$to' BETWEEN `from` AND `to`) AND status <> 'R' " );

foreach ($_REQUEST[bkng] as $rmvalue )


{


for ($x  = 0; $x < $cont.length; $x ++  )


{


if( $cont[$x] === $rmvalue )

{


$rm_found = false;


}




}



}



if($rm_found) {


  $table_name = $wpdb->prefix . 'db_reservations';
   
  $wpdb->insert( 
   
         $table_name, 

         array( 

                'fromdate' => $from,
                'todate' => $to,
                'dateheld'=>$timeheld,
                'lengthofstay'=>$days,
                

               ) 
  
    );

       



   $resID = $wpdb->get_row( "SELECT resid FROM $table_name WHERE dateheld = '$timeheld' " );

   $table_name = $wpdb->prefix . 'db_bookings';

$numrooms = 0;

   foreach ($_REQUEST[bkng] as $value)

   {

   
   $adults = $value[adults] + $adults;

   $children = $value[children] + $children;

   $infants = $value[infants] + $infants;

   $table_name = $wpdb->prefix . 'db_rooms';
   
   $res = $wpdb->get_row( "SELECT * FROM  $table_name WHERE rid = '$value[id]' " );
   
   $total = ( $res->price * $days) + $total;

   $html .='<div class="row" id="firstinnerrow">

   <div class="col-sm-6"><p>'.

   $res->name
 
   .'</p>
   </div>
   <div class="col-sm-3">

   <p> USD </p>

   </div>

   <div class="col-sm-3" >

   <p>'.  number_format($res->price * $days, 2, '.', ',') .'</p>

   </div>

   </div>';



   $table_name = $wpdb->prefix . 'db_bookings';

   $wpdb->insert( 
   $table_name, 
   array( 
    'rid' => $value[id], 
    'fromdate' => $from,
                'todate' => $to,
                'status'=>'H',
                'resid'=>$resID->resid
  ) 
  
   );

$numrooms = $numrooms + 1;
   }

  array_push($rmcont,$html);


  $table_name = $wpdb->prefix . 'db_coupons';

  foreach ($_REQUEST[bkngcpn] as $value1)

   {
   
   $resdSC = $wpdb->get_row( "SELECT * FROM $table_name WHERE cid = '$value1[id]' " );


   $table_name = $wpdb->prefix . 'db_reservation_coupons';

   $wpdb->insert( 
   $table_name, 
   array( 
    'cid' => $value1[id], 
    'resid'=>$resID->resid
  ) 
  
   );



   $total_dsc = $resdSC->amount + $total_dsc;

   $html1 .=' <div class="row" id="firstinnerrow">
              <div class="col-sm-6"><p>'.

              $resdSC->name

              .'</p></div>
              <div class="col-sm-3">

              <p> USD </p>

              </div>

              <div class="col-sm-3" >

              <p>('. number_format(($total * $resdSC->amount)/100 , 2, '.', ',').')</p>

              </div>

              </div> ';

    $total = $total - (($total * $resdSC->amount)/100);


   }
  
   $dsc = (($total *  $total_dsc)/100);

   //$total = $total - (($total *  $total_dsc)/100);


$amt = 0;



$addons = array();

$addAmt = 0;

for ($x = 0; $x < sizeof($_REQUEST[addOns]); $x++  ) 

{

$table_name = $wpdb->prefix . 'db_add_ons';

$nm = $_REQUEST[addOns][$x];

$addrow = $wpdb->get_row( "SELECT * FROM $table_name WHERE name = '$nm' " ); 

$table_name = $wpdb->prefix . 'db_reservation_add_ons';
   



if($addrow->frequency == 'night')

{

$amt = ($addrow->price * $days);

$addAmt = $addAmt + $amt;

}

else if ($addrow->frequency == 'person')

{

$amt = ($addrow->price * $adults);

$addAmt = $addAmt + $amt;

}

else if($addrow->frequency == 'room')

{

$amt = ($addrow->price * $numrooms);

$addAmt = $addAmt + $amt;

}

$wpdb->insert( 
   
         $table_name, 
  
         array( 

                'resid' => $resID->resid,
                'aid' => $addrow->aid,
                'amount'=> $amt,

              ) 
  
    );

$htmlamt .='  <div class="row" id="firstinnerrow">

              <div class="col-sm-6"><p>'.

              $_REQUEST[addOns][$x]

              .'</p></div>

              <div class="col-sm-3">

              <p> USD </p>

              </div>

              <div class="col-sm-3" >

              <p>'. number_format( $amt, 2, '.', ',').'</p>

              </div>

              </div> ';



}


array_push($rmcont,$htmlamt);


   $table_name = $wpdb->prefix . 'db_reservations';

   $total1 = $total + $addAmt;

   $total = number_format($total1,2, '.', ',');

   $wpdb->update( 

   $table_name, 

   array('adults'=>$adults,'children'=>$children,'infants'=>$infants,'total'=>$total1,'discount'=>$dsc,'addOnAmt' => $addAmt),

   array('resid' => $resID->resid)
  
    );

  


   array_push($cont,$html);

   array_push($cont,$html1);

   array_push($cont,$resID->resid);

   array_push($cont,$total);

 array_push($cont,$htmlamt);



}
else {

array_push($cont,'One or more of those rooms is no longer available');

}




   echo json_encode($cont);

   wp_die();


}





}


?>
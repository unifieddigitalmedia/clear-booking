<?php

header("Access-Control-Allow-Origin: *");

header("Content-Type: application/json; charset=UTF-8");

class db_reserve_class_offers 

{
  


 
 public static function db_reserve_class_offers_()
  

  {


      add_action( 'wp_ajax_offers', array( __CLASS__, 'offers_action' ) );
      add_action( 'wp_ajax_nopriv_offers', array( __CLASS__, 'offers_action' ) );


  }



public function offers_action() {


   $cont = array();

   ob_clean();

   global $wpdb;

   $table_name = $wpdb->prefix . 'db_coupons';

   $date = str_replace('/', '-', $_REQUEST[fromdate]);

   $coupon_valid = date('Y-m-d', strtotime($date));

   $date1 = str_replace('/', '-', $_REQUEST[todate]);

   $coupon_expiry = date('Y-m-d', strtotime($date1));

   $cont = $wpdb->get_results( "SELECT * FROM $table_name WHERE (('$coupon_valid' BETWEEN `validdate` AND `exdate`) AND ('$coupon_expiry' BETWEEN `validdate` AND `exdate`)) OR token = '$_REQUEST[promo]'
 " );
   
   if(empty($cont)){ $html .=''; } else {  
   

foreach ( $cont as $con ) 


{

         $html .='<div id="firstinnerrow" ><div class="row" >
         <div class="col-sm-10">'.$con->name.'</div>
         <div class="col-sm-2"></div>
         </div>

         <div class="row">
         <div class="col-sm-10">'.$con->description.'</div>
         <div class="col-sm-2"><p   id="cpnbtn" type="button" value="'.$con->cid.'">ADD</p></div>
         </div></div>';

}


 }

   echo $html;

   wp_die();





}





}


?>
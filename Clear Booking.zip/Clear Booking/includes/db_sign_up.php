<?php


header("Access-Control-Allow-Origin: *");

header("Content-Type: application/json; charset=UTF-8");



class db_sign_up 

{
  


 
 public static function db_sign_up_()
  

  {


      add_action( 'wp_ajax_signup', array( __CLASS__, 'signup_action' ) );
      add_action( 'wp_ajax_nopriv_signup', array( __CLASS__, 'signup_action' ) );


  }



public function signup_action() {


   $cont = array();

   $outercont = array();

   ob_clean();

   global $wpdb;

   $table_name = $wpdb->prefix . 'db_members';
   
   $userdetails = $wpdb->get_var( "SELECT COUNT(*) FROM $table_name WHERE username = '$_REQUEST[username]'" );


if($userdetails != 0 )
{

echo json_encode("Username already registered");
 wp_die();

}
else
{

$table_name = $wpdb->prefix . 'db_reservations';
   
$reservationdetails = $wpdb->get_var( "SELECT COUNT(*) FROM $table_name WHERE email = '$_REQUEST[username]'" );

if($reservationdetails != 0 )
{

$table_name = $wpdb->prefix . 'db_reservations';
   
$pdetails = $wpdb->get_results( "SELECT * FROM $table_name WHERE email = '$_REQUEST[username]'" );

$size = sizeof($pdetails) - 1;

if($pdetails[$size]->lengthofstay < 3 )
{

$term = "Gold";

}
else if($pdetails[$size]->lengthofstay >= 7)
{

$term = "Black";

}


else if($pdetails[$size]->lengthofstay <= 6 && $pdetails[$size]->lengthofstay >= 3)

{

$term = "Platinum";

}

$table_name = $wpdb->prefix . 'db_members';

   $wpdb->insert( 
   $table_name, 
   array( 
    'username' => $_REQUEST[username], 
    'password'=>$_REQUEST[password],
    'firstname'=>$pdetails[$size]->firstname,
    'lastname'=>$pdetails[$size]->lastname,
    'email'=>$pdetails[$size]->email,
    'mtype'=>$term,


  ) 
  
   );

echo json_encode("Clear");

 wp_die();

}
else

{




echo json_encode("No reservation was found for this email address. You will need to make a reservation to become a member.");

 wp_die();

}

}

}


}

?>
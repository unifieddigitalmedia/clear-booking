<?php

header("Access-Control-Allow-Origin: *");

header("Content-Type: application/json; charset=UTF-8");

$json = file_get_contents('php://input');

$obj = json_decode($json);


$month = 10 ;
$num = 1;
$month = $month + $num ; 


$today = getdate();

$calendar = array();

$date = array();

if($month < $today[mon])
{

$period = $today[year]+1 ;

}
else
{

$period = $today[year];

}
$number = cal_days_in_month(CAL_GREGORIAN,$month,$period);


$count = 0 ;

$day = 1;


$html .='<table class="table table-bordered" >
<thead>
<tr>
<th colspan="7" style="width:100%;text-align:center;">




</th>
</tr>
<tr>
';

for ($y = 0 ; $y <= 6 ; $y++)

{


$html .='<td class="tableheading" style="width:5px;height:5px;">'.jddayofweek($y-1,2).'</td>';


}

$html .='</tr>';


for ($x = 0 ; $x < 6 ; $x++)

{


$html .='<tr>';

for ($y = 0 ; $y <= 6 ; $y++)

{


if(($x == 0 && $y < date("w",mktime(0, 0, 0,$month,1,$period))) || ( $day > $number  )  )

{




$html .='<td >blank</td>';

}
else
{

$fd = date("Y-m-d",mktime(0, 0, 0,$month,$day,$period));

$dayname = jddayofweek($y-1,2);



$day = date("d",mktime(0, 0, 0,$month,$day,$period));



$html .='<td class="daydiv">'.$period.'</td>';



$day = $day +1;

$count = $count + 1;



}


}

$html .='</tr>';

}

$html .='</thead></table>';



echo json_encode($html);



?>
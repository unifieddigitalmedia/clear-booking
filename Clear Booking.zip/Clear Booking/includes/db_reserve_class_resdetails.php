<?php


 header("Access-Control-Allow-Origin: *");

 header("Content-Type: application/json; charset=UTF-8");

 class db_reserve_class_resdetails 

{
 


 
 public static function db_reserve_class_resdetails_()
  

  {


      add_action( 'wp_ajax_resdetails', array( __CLASS__, 'resdetails' ) );

      add_action( 'wp_ajax_nopriv_resdetails', array( __CLASS__, 'resdetails' ) );


  }


public function resdetails() {

   ob_clean();

   global $wpdb;

   $table_name = $wpdb->prefix . 'db_reservations';
   
   $wpdb->update( 
   $table_name, 
   array( 
              
                'firstname'=>$_REQUEST['firstname'],
                'lastname'=>$_REQUEST['lastname'],
                'phone'=>$_REQUEST['phone'],
                'email'=>$_REQUEST['email'],
           
  
  ),
    array('resid'=>$_REQUEST['reservationID']));

  

    wp_die();


}





}


?>
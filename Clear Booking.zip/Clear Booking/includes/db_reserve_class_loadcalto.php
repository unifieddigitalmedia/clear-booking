<?php


class db_reserve_class_loadcalto 

{
  


 
 public static function db_reserve_class_loadcalto_()
  

  {


      add_action( 'wp_ajax_loadcalto', array( __CLASS__, 'load_cal' ) );

      add_action( 'wp_ajax_nopriv_loadcalto', array( __CLASS__, 'load_cal' ) );


  }



public function load_cal() {

       ob_clean();

       $json = file_get_contents('php://input');

$obj = json_decode($json);

$month = $_REQUEST[month] ;

$num = 1;

$month = $month + $num ; 

$today = getdate();

$calendar = array();

$date = array();

if($month < $today[mon])
{

$period = $today[year]+1 ;

}
else
{

$period = $today[year];

}

$number = cal_days_in_month(CAL_GREGORIAN,$month,$period);

$count = 0 ;

$day = 1;

$monthName = date('F', mktime(0, 0, 0,$month,'10')) ;
$html .='<table class="table table-bordered" >

<thead>

<tr>

<td colspan="2"> <p data-id="'.$month.'" class="topre"> Previous </p>  </td>
<td colspan="3"> <p>'. $monthName .' </p> </td>
<td colspan="2"> <p data-id="'.$month.'" class="tonxt"> Next </p>  </td>

</tr>

<tr>';

for ($y = 0 ; $y <= 6 ; $y++)

{


$html .='<td class="tableheading" style="width:5px;height:5px;">'.jddayofweek($y-1,2).'</td>';


}

$html .='</tr>';


for ($x = 0 ; $x < 6 ; $x++)

{


$html .='<tr>';

for ($y = 0 ; $y <= 6 ; $y++)

{


if(($x == 0 && $y < date("w",mktime(0, 0, 0,$month,1,$period))) || ( $day > $number  )  )

{




$html .='<td ></td>';

}
else
{

$fd = date("Y-m-d",mktime(0, 0, 0,$month,$day,$period));

$day = date("d",mktime(0, 0, 0,$month,$day,$period));

$html .='<td class="todaydiv" data-id="'.$month.'" >'.$day.'</td>';



$day = $day +1;

$count = $count + 1;



}


}

$html .='</tr>';

}

$html .='</thead></table>';




  
       echo $html;

       wp_die();


}





}


?>
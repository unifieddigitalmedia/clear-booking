<?php



class db_reserve_content 

{
 


 

public static function db_reserve_details_($content) {

 if( is_page(get_option("db_cancel_page")))
{

  global $wpdb;

  $table_name = $wpdb->prefix . 'db_reservations';
  
  $wpdb->delete( $table_name, array( 'resid' => $_REQUEST[reservationID] ) );


  $table_name = $wpdb->prefix . 'db_bookings';

  $wpdb->delete( $table_name, array( 'resid' => $_REQUEST[reservationID] ) );

return $content;

}
 else if ( is_page( get_option('db_details_page') ) ||  is_page(get_option("db_confirmation_page") ) ) {



 require_once $_SERVER[DOCUMENT_ROOT].'/wp-content/plugins//DragonBayInnReserve/includes/db_functions.php';
 
 

 
       $requestPart = explode("reservationID", $_SERVER['REQUEST_URI']);
    

       $requestPart = explode("=",$requestPart[1]);

 
  if(isset($_REQUEST[token]))

{


 require_once $_SERVER[DOCUMENT_ROOT].'/wp-content/plugins//DragonBayInnReserve/PayPal/paypalfunctions.php';
 
 //require_once '/home/udigitalmedia32/public_html/PayPal/paypalfunctions.php';
 
 confirm_transaction($_REQUEST[token],$_REQUEST[PayerID],$_REQUEST[reservationID]);

 

}

 if($_GET[CHECKOUT]){
        
        if ($_SERVER['REQUEST_METHOD']=='GET')
            
        {
     

           


             //require_once '/home/udigitalmedia32/public_html/PayPal/paypalfunctions.php';
   
             require_once $_SERVER[DOCUMENT_ROOT].'/wp-content/plugins/DragonBayInnReserve/PayPal/paypalfunctions.php';


            $asd = explode('&',urldecode(get_contents($_REQUEST[PAYMENTREQUEST_0_AMT],$_REQUEST[reservationID])));

        

             $asd = explode("=",$asd[0]);

       

             payredirect($asd[1]);




}




}
       
   global $wpdb;


   $table_name = $wpdb->prefix . 'db_reservations';
   
   $resID = $wpdb->get_row( "SELECT * FROM $table_name WHERE resid = '$_REQUEST[reservationID]' " );

  
$value =  $resID->fromdate ;
$day =  substr("$value",8,2);
$month = substr("$value",5,2);
$year =  substr("$value",0,4);
$date = $day."/".$month."/".$year;


$value =  $resID->todate ;
$day =  substr("$value",8,2);
$month = substr("$value",5,2);
$year =  substr("$value",0,4);
$date1 = $day."/".$month."/".$year;


if(is_page( get_option('db_confirmation_page')  ))
{

$tlt = 'Your Reservation Confirmation';
}
else if( is_page(get_option("db_details_page")))
{

$tlt = 'Your Reservation Details';

}

      $content  .= '<body onload="loadfb()">



                   <h1>'. $tlt .'</h1>

                   <div id="rescontent" role="main" class="container-fluid">

                   <div class="row" >
  
                   <div class="col-sm-5">  

                   <div class="row" >

                   <div class="col-sm-12" >

                   <h4 class="resDetails_header">'.'-'.$date.' - to - '.$date1.'</h4>

                   </div>

                   </div>';

                   $table_name = $wpdb->prefix . 'db_bookings';

                   $rms_results = $wpdb->get_results( "SELECT rid FROM $table_name WHERE resid = '$_REQUEST[reservationID]' " );
$subtotal = 0;
                   foreach ( $rms_results as $rms_result ) 
                   
                   {


                   $table_name = $wpdb->prefix . 'db_rooms';

                   $rms = $wpdb->get_row( "SELECT * FROM $table_name WHERE rid = '$rms_result->rid' " );


$content    .= '<div class="row" >

             <div class="col-sm-6">'.

             $rms->description

             .'</div>

             <div class="col-sm-3" >

             '.$resID->lengthofstay.' days @'.$rms->price.'/night

             </div>

             <div class="col-sm-3" >

             '.number_format($rms->price*$resID->lengthofstay, 2, '.', ',').'

             </div>

             </div>';

$subtotal = $subtotal + $rms->price*$resID->lengthofstay;

}


$content    .= '<h4 class="resDetails_header" >Amenities </h4>';


$table_name = $wpdb->prefix . 'db_reservation_add_ons';

$addonsID = $wpdb->get_results( "SELECT * FROM $table_name WHERE resid = '$_REQUEST[reservationID]' " );

$addons = 0;

foreach ( $addonsID as $addonID ) 

{

$table_name = $wpdb->prefix . 'db_add_ons';

$addonsDes = $wpdb->get_row( "SELECT * FROM $table_name WHERE aid = '$addonID->aid' " );

$content    .= '<div class="row">

             <div class="col-sm-6">'.

             $addonsDes->name

             .'</div>

             <div class="col-sm-3">

             <p> USD </p>

             </div>

             <div class="col-sm-3" >'.number_format($addonID->amount,2, '.', ',')
              .'

             </div>

             </div>';


$addons  = $addons + $addonID->amount;


}

$content    .= '<h4 class="resDetails_header" >Offers </h4>';

$discount = 0;
$table_name = $wpdb->prefix . 'db_reservation_coupons';

$cpnsID = $wpdb->get_results( "SELECT * FROM $table_name WHERE resid = '$_REQUEST[reservationID]' " );

$total = $resID->total;

foreach ( $cpnsID as $cpnID ) 

{

$table_name = $wpdb->prefix . 'db_coupons';

$cpnsDes = $wpdb->get_row( "SELECT * FROM $table_name WHERE cid = '$cpnID->cid' " );

$content    .= '

             <div class="row">

             <div class="col-sm-6">


             <div class="row">

             <div class="col-sm-6">'.

             $cpnsDes->name

             .'</div>

             <div class="col-sm-3">

             <p> USD </p>

             </div>

             <div class="col-sm-3" >('.

             (($total * $cpnsDes->amount)/100).')

             </div>

             </div>';

$total = $total - (($total * $cpnsDes->amount)/100);

$discount = $discount + (($total * $cpnsDes->amount)/100);
}

$content    .= '<h4 class="resDetails_header" >Personal Details </h4>

             <div class="row"  >

             <div class="col-sm-6">

             First Name :

             </div>

             <div class="col-sm-6">'.

             $resID->firstname

             .'</div>

             </div>';

$content    .= '<div class="row"  >

             <div class="col-sm-6">

             Last Name :

             </div>

             <div class="col-sm-6">'.

             $resID->lastname

             .'</div>

             </div>';

$content    .= '<div class="row"  >

             <div class="col-sm-6">

             Phone :

             </div>

             <div class="col-sm-6">'.

             $resID->phone 

             .'</div>

             </div>';

$content    .= '<div class="row"  >

             <div class="col-sm-6">

             Email :

             </div>

             <div class="col-sm-6">'.

             $resID->email

             .'</div>

             </div>';

$content    .= ' <h4 class="resDetails_header">Dependents </h4>

              <div class="row" >

              <div class="col-sm-6" >

              Adults :

              </div>

              <div class="col-sm-6">'.

              $resID->adults

              .'</div>

              

              </div>';


$content    .= ' 
              <div class="row" >

              <div class="col-sm-6" >

              Children :

              </div>

              <div class="col-sm-6">'.

              $resID->children

              .'</div>

              

              </div>';


$content    .= ' 

              <div class="row" >

              <div class="col-sm-6" >

              Infants :

              </div>

              <div class="col-sm-6">'.

              $resID->infants

              .'</div>

              

              </div>';



$content    .= '<div class="row" >
             <div class="col-sm-6">

             <p>  Tax </p>
             </div>

             <div class="col-sm-3">

             <p> USD </p>

             </div>

             <div class="col-sm-3">

             <p>  </p>

             </div>

             </div>


             <h4 class="resDetails_header"> TOTAL</h4> 

              <div class="row" >
             <div class="col-sm-6" >

            

             </div>
             <div class="col-sm-3">

             <p> USD </p>

             </div>

             <div class="col-sm-3" >

             <p>'. $resID->total .'</p>

             </div>

             </div>

            

             
            

             
  

';


   

$confirm_page = get_option("db_confirmation_page");


$thank_you_page = get_option("db_thankyou_page");



 if ( is_page(get_option("db_confirmation_page") ) ) 

{


$content    .= '</div>
 <div class="col-sm-2"> 
</div>

             <div class="col-sm-5" style="vertical-align:middle;text-align:center;"> 

       <div class="row" >

                   <div class="col-sm-12" >

                

                   </div>

                   </div>




<h3> <a href="../thank-you/" > click here to continue </a> </h3>
</div>

             </div> </div>
      
                   </body>';

}else

{

$table_name = $wpdb->prefix . 'db_bookings';

$deposit = 0;

$rooms = $wpdb->get_results( "SELECT rid FROM $table_name WHERE resid = '$_REQUEST[reservationID]'");

$table_name = $wpdb->prefix . 'db_rooms';

foreach ( $rooms as $room ) 

{

$room_price = $wpdb->get_row( "SELECT price FROM $table_name WHERE rid = '$room->rid'");


$deposit = $deposit + $room_price->price;


}

 $account = get_option('db_paypal_api_username'); 


$d_policy = get_option('db_deposit_policy');

$c_policy = get_option('db_cancel_policy');

$r_policy = get_option('db_refund_policy');

$deposit_policy = cal_amt_to_pay($_REQUEST[reservationID],$deposit);


 $content    .='</div>
              <div class="col-sm-2"> 
</div>

             <div class="col-sm-5" style="vertical-align:middle;"> 


<div class="row" >

                   <div class="col-sm-12" >

                  <h4 class="resDetails_header">Summary </h4>

                   </div>

                   </div>





<div class="row">
 
  <div class="col-sm-4">Period</div>
  <div class="col-sm-2">Sub Total</div>
  <div class="col-sm-2">Discount</div>
  <div class="col-sm-2">Amenities</div>
  <div class="col-sm-2">Tax</div>

</div>
<div class="row">
 
  <div class="col-sm-4">'.$date.' - '.$date1.'</div>
  <div class="col-sm-2">'.number_format($subtotal, 2, '.', ',').'</div>
  <div class="col-sm-2">('.number_format($discount, 2, '.', ',').')</div>
  <div class="col-sm-2">'.number_format($addons, 2, '.', ',').'</div>
  <div class="col-sm-2"></div>

</div>
<div class="row">
  <div class="col-sm-2"></div>
  <div class="col-sm-2"></div>
  <div class="col-sm-2"></div>
  <div class="col-sm-2"></div>
  <div class="col-sm-2">Total</div>
  <div class="col-sm-2">'.number_format($resID->total, 2, '.', ',').'</div>

</div>

<div class="row">
  <div class="col-sm-2"></div>
  <div class="col-sm-2"></div>
  <div class="col-sm-2"></div>
  <div class="col-sm-2"></div>
  
  <div class="col-sm-4"> 



                <form   id="myContainer" method="GET" action="../reservation-details/">
	      
                <input  type="hidden" name="PAYMENTREQUEST_0_AMT" value="'.$deposit.'">
	
                <input  type="hidden" name="reservationID" value="'.$_REQUEST[reservationID].'">

                <input  type="hidden" name="CHECKOUT" value="SUBMIT">
                
                </form>


  </div>

  </div>


<p> Rates are per room per night, quoted in U.S. dollars, are based on double occupancy per room. Rates quoted are plus 26.5% Government tax and service charge. </p>


&nbsp;


<h4>DEPOSIT POLICY:</h4>

&nbsp;
<p style="text-align:left;">$'.$deposit_policy.'</p>  

&nbsp;

<h4>CANCELLATION, NO-SHOW AND REFUND POLICIES:</h4>
&nbsp;
<p>'.$c_policy.'</p>  
&nbsp;
<p>'.$r_policy.'</p>      
               
    
&nbsp;
         
                </div>

                </div>
               
                </body>



<script>
      window.paypalCheckoutReady = function () {
        paypal.checkout.setup("'.$account.'", {
            environment: "sandbox",
            container: "myContainer"
          });
      };
    </script>

    <script src="http://www.paypalobjects.com/api/checkout.js" async></script>



';



}
      return $content;

      wp_die();


    }
else if(is_page( get_option('db_reservation_page') ))

{


  
   global $wpdb;

 if($_POST[trip]){
        
        if ($_SERVER['REQUEST_METHOD']=='POST')
            
        {
 

foreach ($_REQUEST[trpPlace] as $key => $value)

{

$table_name = $wpdb->prefix . 'db_trip';
   
  $wpdb->insert( 
   
         $table_name, 

         array( 

              
                'place' => $value,
                'token'=>$_REQUEST[token],
                'distance'=>$_REQUEST[distance],
               
                

               ) 
  
    );

}





        }

        }


$from = $_REQUEST[from];

 $content  .= '<body onload="checkavailability()">

                   <div class="row" >

<div class="col-sm-3" id="bookinglabel" ><h3> Reserve online </label> </div><div class="col-sm-9" ></h3> </div>

</div>

<div class="row" ng-hide="availabilty">

<div class="col-sm-3" id="checkavaiabiltyrow" >

<div class="form-group has-success has-feedback">

<select id="travellers" class="form-control" name="room" ng-model="travellers">

<option >SELECT A SUITE</option>


</select>  


</div> 



</div>



<div class="col-sm-2" id="checkavaiabiltyrow">

<div class="form-group has-success has-feedback">

<input type="text" class="form-control"  id="fromdate" placeholder="'.$_REQUEST[from].'" data-id="'.$_REQUEST[from].'"> 

<span class="glyphicon glyphicon-th form-control-feedback"></span> 

</input> 

</div>

</div>

<div class="col-sm-2" id="checkavaiabiltyrow" >

<div class="form-group has-success has-feedback">

<input type="text" class="form-control" id="todate" placeholder="'.$_REQUEST[to].'" data-id="'.$_REQUEST[to].'"> 

<span class="glyphicon glyphicon-th form-control-feedback"></span>  

</input> 

</div>

</div>


<div class="col-sm-2" id="checkavaiabiltyrow" >

<div class="form-group has-success has-feedback">

<input id="promo" class="form-control" type="text" placeholder="PROMO CODE" name="promo"  data-id="'.$_REQUEST[promo].'"> 

<span class="glyphicon glyphicon-qrcode form-control-feedback"></span>

</div>

</div>

<div class="col-sm-3" id="checkavaiabiltyrow" >

<div class="form-group has-success has-feedback">
<button class="btn btn-default btn-block" type="button" id="checkavailability" >CHECK AVAILABILITY</button> 

<span ></span>
</div>

</div>

</div>

</div>

<div id="errormessage" class="checking"> <p id="error">  </p> </div>

<div class="row" id="calenderrow">
<div class="col-sm-6" id="frommonth">

</div>

<div class="col-sm-6" id="tomonth">

</div>


</div>

<div class="row" >


   <div class="col-sm-6"> 

   <div class="row" id="availablecol">

   <div class="col-sm-12" > 
  
   <div class="row" id="toprow"> <div class="col-sm-12"> <p>Available rooms<p> </div>  </div>

   <div class="arooms" > </div>

   

   
   </div>
   
   </div>



   <div class="row" id="availablecoloffs">

   <div class="col-sm-12"> 
  
   <div class="row" id="toprow"> <div class="col-sm-12"> <p>Offers <p> </div>  </div>
   
   <div class="acpns"> </div>


   </div>
   
   </div>



  </div>





  <div class="col-sm-6">


   <div class="row" id="bookingcol">

   <div class="col-sm-12"> 
  
   <div class="row" id="toprow"> <div class="col-sm-12"> <p>Your booking<p> </div>  </div>

   <div class="bkng" >  </div> 

   <div class="row" id="toprow"> <div class="col-sm-12"> <p>Discounts<p> </div>  </div>

   <div class="bkngcpt" >  </div>

   <div class="row" id="toprow"> <div class="col-sm-12"> <p>Add ons<p> </div>  </div>
   <div class="bkngaddons"> </div>

  &nbsp;
  <div class="row" >
  <div class="col-sm-6" >

  Do you have a planned trip code 

  </div>
  <div class="col-sm-6" >

  <p>  </p>

  </div>


  </div>
  &nbsp;
  <div class="row" >
  <div class="col-sm-4" >

  <div class="row" >
  <div class="col-sm-6"> <label><input type="radio" name="plannedtrip" class="trip" value="yes" >&nbsp;Yes&nbsp;</label></div>
  <div class="col-sm-6"> <label><input type="radio" name="plannedtrip" class="trip" value="no">&nbsp;No&nbsp;</label></div>

   </div>

   </div>
   <div class="col-sm-8">

   <p>  </p>

   </div>

   </div>
&nbsp;

   <div class="row" id="plannedtripcodediv" >
   <div class="col-sm-6" >

   <div class="row"  >

   <div class="form-group">

   PLANNED TRIP CODE:

   <input type="text" class="form-control" id="plannedtrip" name="plannedtrip" value="'.$_REQUEST[token].'" >

   </div>

   </div>

   </div>

   <div class="col-sm-6">

   <p>  </p>

   </div>

   </div>
  <div class="row" id="toprow" > 

  <div class="col-sm-6"> <p><p> </div> 

  <div class="col-sm-3"> <p><p> </div>

  <div class="col-sm-3"> <p><button class="btn btn-default btn-block" type="button"  id="chkrates"> CONTINUE</button><p>     </div>  

  </div>

  </div>
  </div>




   <div class="row" id="ratescol">

   <div class="col-sm-12"> 
  
   <div class="row"id="toprow" > <div class="col-sm-12"> <p>Rates<p> </div>  </div>

   <div> </div>

   <div class="row" id="toprow"> <div class="col-sm-12"> <p>Rooms<p> </div>  </div>

   <div class="rtsrms"> </div>

   <div class="row" id="toprow"> <div class="col-sm-12"> <p>Add ons<p> </div>  </div>

   <div class="rtsaddons">  </div>

  

   <div class="row" id="toprow"> <div class="col-sm-12"> <p>Offer<p> </div>  </div>
   <div class="rtsoffs"> </div>
   <div class="row" id="firstinnerrow"> <div class="col-sm-6">  <p>Tax<p> </div> <div class="col-sm-3"> <p><p> </div><div class="col-sm-3"> <p><p> </div>  </div>
   <div> </div>
   <div class="row" id="toprow"> <div class="col-sm-6"> <p>Total<p> </div> <div class="col-sm-3"> <p><p> </div><div class="col-sm-3"> <p class="rtstlt"><p> </div>  </div>
   <div> </div>

   <div class="row" id="toprow"> <div class="col-sm-6"> <p><p> </div> <div class="col-sm-3"> <p><p> </div><div class="col-sm-3"> <p><button class="btn btn-default btn-block" type="button" id ="totalid" > CONTINUE</button><p> </div>  </div>
   </div>
   
   </div>';


 $r = get_option('db_details_page');


$content    .= '   <form action="../'.$r .'/" method="post" id="detailsform" class="detailsform" name="detailsform">
   <div class="row" id="detailscol">

   <div class="col-sm-12"  > 
  
   <div class="row" id="firstinnerrow"> 

   <div class="col-sm-6"> <input type="text" class="form-control" id="resfirstname" placeholder="Enter first name" >  </div> 


   <div class="col-sm-6"> <input type="text" class="form-control" id="reslastname" placeholder="Enter last name" >  </div>  

   
   </div>


   <div class="row" id="firstinnerrow"> 

   <div class="col-sm-6"> <input type="text" class="form-control" id="resphone" placeholder="Enter phone" >  </div> 


   <div class="col-sm-6"> <input type="text" class="form-control" id="resemail" placeholder="Enter email" >  </div>  

   
   </div>

   <span id="detailserror">  </span>

  



   <div class="row" id="firstinnerrow"> ';


$r = get_option('db_terms_page');




$content    .= '<div class="row" id="firstinnerrow"> 

   <div class="col-sm-12"> <label><input type="checkbox" id="ckhterms" > You must agree to the terms of our villa <a href="../'.$r.'/" > here</a> to stay with us </label> </div> 


  

   
   </div>

   

   <div class="row" id="toprow"> 

   <div class="col-sm-6">  </div> 


   <div class="col-sm-6"> <button type="button" class="btn btn-default btn-block" id="chkbtn" name="resID" >CONTINUE</button> </div>  

   
   </div>

   <input type="hidden" name="reservationID" id="chkbtn" class="chkbtn" >


</form>


   </div>
   
   </div>








   </div>





</div> </body>';

 return $content;
}
   else {

        return $content;

    }




}





}


?>
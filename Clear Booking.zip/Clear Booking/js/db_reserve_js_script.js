reservationrooms = [];

reservationcpns = [];

if (window.location.hash == '#_=_') {
        open(location, '_self').close();
}


 window.fbAsyncInit = function() {

  FB.init({
  appId      : "1126447664054676", 
  xfbml      : true,
  version    : 'v2.5'
  
  });




   };


(function(d){
     var js, id = 'facebook-jssdk', ref = d.getElementsByTagName('script')[0];
     if (d.getElementById(id)) {return;}
     js = d.createElement('script'); js.id = id; js.async = true;
     js.src = "//connect.facebook.net/en_US/all.js";
     ref.parentNode.insertBefore(js, ref);
   }(document));



function signupfb() {

 FB.getLoginStatus(function(response) {

    SignupStatusChangeCallback(response);

    });


}

function SignupStatusChangeCallback(response) {



    if (response.status === 'connected') {

     
     SignUptestAPI();


    } else if (response.status === 'not_authorized') {



FB.login(function(response) {



 SignupStatusChangeCallback(response);

  }, {scope:'public_profile,email'});



    } else if (response.status === 'unknown') {
      




    }
  }

function SignUptestAPI() {


FB.api('/me', function(response) {
    



var data = {


              'action':'signup',
              'email':response.email,
              'password':'',
              'dataType':'json',
                
           };



jQuery.post(ajax_object.ajax_url, data, function(response) {

if(response == 'Clear')

{

document.getElementById("confirmform").submit();

}


else

{

document.getElementById("error").innerHTML = response;

}



});



});

  }


function checkavailability ()

{


var f = document.getElementById('fromdate').getAttribute('data-id');



var t = document.getElementById('todate').getAttribute('data-id');


var p = document.getElementById('promo').getAttribute('data-id');

if(f != "" || t != "")

{

var data = {


              'action':'rooms',
              'from':f,
              'to':t,
              'dataType':'json',
                
           };



jQuery.post(ajax_object.ajax_url, data, function(response) {


$(".arooms").html(response);

$("#availablecol").slideDown("slow");



});






var data = {


              'action':'offers',
              'fromdate':f,
              'todate':t,
              'promo':p,
             
                
           };





jQuery.post(ajax_object.ajax_url, data, function(response) {



$(".acpns").html(response);

$("#availablecoloffs").slideDown("slow");




});







}









}



function myFunction(p){



alert('this is a ID' + p );



}

function getResdetails(P){


var data = {


              'action':'reservationdetails',
              'resID':P,
              'dataType':'json',
                
           };

jQuery.post(ajax_object.ajax_url, data, function(response) {



$("#content").html(response);


});


}



function validateDates(from,to) {


var today = new Date();

var fromarray = from.split("/");

var toarray = to.split("/");

var startDate = new Date(fromarray[2],Number(fromarray[1])-1,fromarray[0]); 

var endDate = new Date(toarray[2],Number(toarray[1])-1,toarray[0]);



if( startDate > endDate )

{


return 'Please check you check out date.';


} 

else if(today > startDate || today > endDate)

{


return 'Dates cannot be in the past.';


}
else if( endDate ==  'Invalid Date' || startDate == 'Invalid Date')
{

return 'Please check your reservation dates.';


}

else
{

return '';


}

 

}

jQuery(document).ready(function() {


$("#availablecol").hide();


$("#availablecoloffs").hide();

$("#bookingcol").hide();

$("#ratescol").hide();

$("#detailscol").hide();

$(".checking").hide();

 $("#plannedtripcodediv").hide();



$('input[type=radio][name=plannedtrip]').change(function() {

        if (this.value == 'yes') {

          $("#plannedtripcodediv").slideDown("slow");

        }
        else if (this.value == 'no') {

         $("#plannedtripcodediv").slideUp("slow");

        }

    });


$("#checkavailability").click(function(){




$(".checking").slideDown("slow");


setTimeout(function(){ 


$(".checking").slideUp("slow");


 }, 2000);


var error = validateDates($("#fromdate").val(),$("#todate").val());

if(error == '')


{




document.getElementById("error").innerHTML = 'Checking availability';



setTimeout(function(){ 


$("#calenderrow").slideUp("slow");

var d = document.getElementById("shortcodeform");



 }, 2000);



if (document.getElementById("shortcodeform")) 

{

setTimeout(function(){ 

document.getElementById("shortcodeform").submit();

 }, 2000);


}
else
{

var data = {


              'action':'rooms',
              'from':$("#fromdate").val(),
              'to':$("#todate").val(),
              'dataType':'json',
                
           };



jQuery.post(ajax_object.ajax_url, data, function(response) {


$(".arooms").html(response);

$("#availablecol").slideDown("slow");



});






var data = {


              'action':'offers',
              'fromdate':$("#fromdate").val(),
              'todate':$("#todate").val(),
              'promo':$("#promo").val(),
             
                
           };





jQuery.post(ajax_object.ajax_url, data, function(response) {



$(".acpns").html(response);

$("#availablecoloffs").slideDown("slow");




});



}


}
else
{

document.getElementById("error").innerHTML = error;

}



});



$(document).on("click",".bkngrmrmv",function(event){

bkngrm = $(this).attr("data-id");

reservationrooms = jQuery.grep(reservationrooms, function( a,i ) { 


return ( a.id !== bkngrm ); 



});



        bkng();

});


$(document).on("click","#roombtn",function(event){



if(!rmad($(this).attr("value"),reservationrooms))

{



  var rm = {

    id : $(this).attr("value"),
    adults:"0",
    children:"0",
    infants :"0"

};

  reservationrooms.push(rm);




}




      bkng();

});


$(document).on("click","#cpnbtn",function(event){

if(!rmad($(this).attr("value"),reservationcpns))

{



  var rm = {


    id : $(this).attr("value"),

           };

  reservationcpns.push(rm);


}




bkng();



});


$(document).on("click",".cptrmrmv",function(event){

cptgrm = $(this).attr("data-id");

reservationcpns = jQuery.grep(reservationcpns, function( a,i ) { 


return ( a.id !== cptgrm ); 



});


        bkng();

});




$(document).on("click","#chkrates",function(event){

var addons = [];

var f = $('input[type=radio]:checked');



for (var i = 0, length = f.length; i < length; i++) {

 
if(f[i].value == 'yes')
{


 addons.push(f[i].name);


}


       

}

adltIn = document.getElementsByName("adults");


cldIn  = document.getElementsByName("children");



iftIn  = document.getElementsByName("infants");



reservationrooms = jQuery.grep(reservationrooms, function( a,i ) { 



  a.adults = adltIn[i].value;

  a.children = cldIn[i].value;

  a.infants = iftIn[i].value;


return a; 

});


var data = {

              'action':'bkngtlt',
              'bkng':reservationrooms,
              'bkngcpn':reservationcpns,
              'from':$("#fromdate").val(),
              'to':$("#todate").val(),
              'addOns[]':addons,
              
           };

jQuery.getJSON(ajax_object.ajax_url, data, function(response) {


$(".rtsrms").html(response[0]);

$(".rtsoffs").html(response[1]);

$(".rtstlt").html(response[3]);

$("#chkbtn").val(response[2]);

$(".chkbtn").val(response[2]);

$(".rtsaddons").html(response[4]);

$("#ratescol").slideDown("slow");

$("html,body").animate({scrollTop:$("#ratescol").offset().top }, "slow");



});

});

$(document).on("click","#totalid",function(event){



$("#detailscol").slideDown("slow");


$("html,body").animate({scrollTop:$("#detailscol").offset().top }, "slow");


});



$(document).on("click","#chkbtn",function(event){


var x = document.getElementById("ckhterms").checked;


if( $("#resfirstname").val() === $("#resfirstname").attr('placeholder') || $("#reslastname").val() === $("#reslastname").attr('placeholder')  || $("#resphone").val() === $("#resphone").attr('placeholder')  || $("#resemail").val() === $("#resemail").attr('placeholder') )

{




document.getElementById("detailserror").innerHTML = 'All fields are required';


}


else 


{






if(document.getElementById("ckhterms").checked)
{




var data = {


              'action':'resdetails',
              'reservationID':$(this).attr("value"),
              'firstname':$("#resfirstname").val(),
              'lastname':$("#reslastname").val(),
              'phone':$("#resphone").val(),
              'email':$("#resemail").val(),
            
                

           };

jQuery.post(ajax_object.ajax_url, data, function(response) {



document.getElementById("detailsform").submit();

});



}
else

{


document.getElementById("detailserror").innerHTML = 'You need to agree to our terms and conditions';


}










}






});
function rmad(para,para1) {




for (i = 0; i < para1.length; i++  )


{

if( para1[i].id === para )

{


return true;


}



}


return false;

}



function bkng () {




var data = {


              'action':'bkng',
              'bkng':reservationrooms,
              'bkngcpn':reservationcpns,

                
           };




jQuery.getJSON(ajax_object.ajax_url, data, function(response) {




$(".bkng").html(response[0]);

$(".bkngcpt").html(response[1]);

$(".bkngaddons").html(response[2]);


$("#bookingcol").slideDown("slow");

});



}



$("#calenderrow").hide();



var newdate = new Date();

var current_month = newdate.getMonth();

var current_year = newdate.getFullYear();




$("#fromdate").click(function(){




var data = {


              'action':'loadcal',
              'month':current_month,
              'dataType':'json',
                
           };



jQuery.post(ajax_object.ajax_url, data, function(response) {

$("#frommonth").html(response);

});



var data = {


              'action':'loadcalto',
              'month':current_month,
              'dataType':'json',
                
           };


jQuery.post(ajax_object.ajax_url, data, function(response) {


$("#tomonth").html(response);


$("#calenderrow").slideDown("slow");

});








});


$(document).on("click", ".daydiv", function(){



current_year = Number(current_month)  < getmonth() ?  newdate.getFullYear() + 1 : newdate.getFullYear() ;


var fromdate = $(this).html()+'/'+$(this).attr("data-id")+'/'+current_year;

$("#fromdate").val(fromdate);

current_month = getmonth();


 });


$(document).on("click", ".todaydiv", function(){



current_year = Number(current_month)  < getmonth() ?  newdate.getFullYear() + 1 : newdate.getFullYear() ;


  
var todate = $(this).html()+'/'+$(this).attr("data-id")+'/'+current_year;

$("#todate").val(todate);

current_month = getmonth();




 });



function getmonth() {


var newdate = new Date();

return newdate.getMonth();


}



$(document).on("click", ".frompre", function(){



current_month =  Number(current_month) ==  getmonth() ?  getmonth() : (Number(current_month) <= 0 ? Number(12) - 1:Number(current_month) - 1);



current_year = Number(current_month)  < getmonth() ?  newdate.getFullYear() + 1 : newdate.getFullYear() ;



var data = {


              'action':'loadcal',
              'month':current_month,
              'dataType':'json',
                

           };



jQuery.post(ajax_object.ajax_url, data, function(response) {


$("#frommonth").html(response);



});






 });


$(document).on("click", ".fromnxt", function(){

current_month = Number(current_month) < Number(12) -1 ? ( Number(current_month) == Number(getmonth()) - 1 ? getmonth() - 1 : Number(current_month) + 1) : 0;


current_year = Number(current_month)  < getmonth() ?  newdate.getFullYear() + 1 : newdate.getFullYear() ;

var data = {


              'action':'loadcal',
              'month':current_month,
              'dataType':'json',
                
           };



jQuery.post(ajax_object.ajax_url, data, function(response) {

$("#frommonth").html(response);

});


 });


$(document).on("click", ".topre", function(){



current_month =  Number(current_month) ==  getmonth() ?  getmonth() : (Number(current_month) <= 0 ? Number(12) - 1:Number(current_month) - 1);

current_year = Number(current_month)  < getmonth() ?  newdate.getFullYear() + 1 : newdate.getFullYear() ;


var data = {


              'action':'loadcalto',
              'month':current_month,
              'dataType':'json',
                
           };



jQuery.post(ajax_object.ajax_url, data, function(response) {


$("#tomonth").html(response);



});






 });


$(document).on("click", ".tonxt", function(){

current_month = Number(current_month) < Number(12) -1 ? ( Number(current_month) == Number(getmonth()) - 1 ? getmonth() - 1 : Number(current_month) + 1) : 0;

current_year = Number(current_month)  < getmonth() ?  newdate.getFullYear() + 1 : newdate.getFullYear() ;


var data = {


              'action':'loadcalto',
              'month':current_month,
              'dataType':'json',
                
           };



jQuery.post(ajax_object.ajax_url, data, function(response) {

$("#tomonth").html(response);

});


 });

$("#cpassworddiv").hide();

$(document).on("click", "#signupbtn", function(){

var value = $("#cpassword").val();

var atpos= $("#username").val().indexOf("@");

var dotpos= $("#username").val().lastIndexOf(".");

if($("#username").val() == '' || $("#password").val() == '')

{

document.getElementById("error").innerHTML = 'Both fields are required';


}
else if(atpos < 1 || dotpos < atpos+2 || dotpos+2 >= $("#username").val().length)
{

document.getElementById("error").innerHTML = 'Please check your email';


}
else if(value.length < 8) 
{


document.getElementById("error").innerHTML = 'Password must be at least 8 characters in length';


}
else if($("#cpassword").val() == '') 
{

document.getElementById("error").innerHTML = 'Please confirm your password';


$("#cpassworddiv").slideDown("slow");


}

else if($("#cpassword").val() != $("#password").val()) 

{


$("#cpassworddiv").slideDown("slow");


document.getElementById("error").innerHTML = 'Passwords do not match';


}
else
{

var data = {


              'action':'signup',
              'email':$("#username").val(),
              'password':$("#cpassword").val(),
              'dataType':'json',
                
           };



jQuery.post(ajax_object.ajax_url, data, function(response) {

if(response == 'Clear')

{

document.getElementById("confirmform").submit();

}


else

{

document.getElementById("error").innerHTML = response;

}



});


}




});


});

       
<?php


   header("Access-Control-Allow-Origin: *");

   header("Content-Type: application/json; charset=UTF-8");

   $path = $_SERVER['DOCUMENT_ROOT'];

   include_once $path . '/wp-config.php';

   include_once $path . '/wp-load.php';

   include_once $path . '/wp-includes/wp-db.php';

   include_once $path . '/wp-includes/pluggable.php';

include_once $path . '/wp-includes/http.php';

  
   global $wpdb;


      $table_name = $wpdb->prefix . 'db_users';

      $mylink = $wpdb->get_results( "SELECT * FROM $table_name" );

$contain = array();

      $container = array();


foreach ( $mylink as $user ) 
{
	$comps = array(

     
      'NAME' => "$user->name",
      'ANDROIDREGISTRATIONID' => "$user->androidID",
      'IOSREGISTRATIONID' => "$user->iosID",
      'OCCU' => "$user->occu",
     
       );

}


    
      array_push($container,$comps);

      echo json_encode($container);







?>
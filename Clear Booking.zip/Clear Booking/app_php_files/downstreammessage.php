<?php

header("Access-Control-Allow-Origin: *");

header("Content-Type: application/json; charset=UTF-8");

$url = "https://gcm-http.googleapis.com/gcm/send";

$content_type = "application/json";

$Auth_key ="key=AIzaSyAKmCPpcSUb4L5cSZJvwXuMAwGtoK3WLG8";

$ch = curl_init();


$notification = array(
    "title" => "Portugal vs. Denmark",
    "text" => "5 to 1",
);

$data_array = array(
    "message" => "This is another new message to receiver"
);

$postData = array(
   
    'notification' =>$notification,
    'to' => $_REQUEST[device_token],
 'data'=> $data_array,
    
);



$options = array(CURLOPT_URL => 'https://gcm-http.googleapis.com/gcm/send',
                 CURLOPT_HEADER => true,
                 CURLOPT_HTTPHEADER => array(
        'Authorization:'.$Auth_key,
        'Content-Type:'. $content_type
    ),
CURLOPT_POSTFIELDS => json_encode($postData)
                );



curl_setopt_array($ch, $options);



curl_exec($ch);




curl_close($ch);




?>
<?php

   header("Access-Control-Allow-Origin: *");

   header("Content-Type: application/json; charset=UTF-8");

   $path = $_SERVER['DOCUMENT_ROOT'];

   include_once $path . '/wp-config.php';

   include_once $path . '/wp-load.php';

   include_once $path . '/wp-includes/wp-db.php';

   include_once $path . '/wp-includes/pluggable.php';

   $container = array();

 

   global $wpdb;

   $date = str_replace('/', '-', $_REQUEST[from]);

   $from = date('Y-m-d', strtotime($date));

   $date1 = str_replace('/', '-', $_REQUEST[to]);

   $to = date('Y-m-d', strtotime($date1));

   $table_name = $wpdb->prefix . 'db_bookings';

   $cont = "SELECT rid FROM $table_name WHERE ('$from' BETWEEN `fromdate` AND `todate`) AND ('$to' BETWEEN `fromdate` AND `todate`) AND status = 'R' ";
   
    $table_name1 = $wpdb->prefix . 'db_rooms';

    if(sizeof($cont) == 0)

   { 


    

     $cont = $wpdb->get_results( "SELECT * FROM $table_name1" ); 

   
   

   } 

    else 

   { 


$cont = $wpdb->get_results( "SELECT * FROM $table_name1 WHERE rid NOT IN (SELECT rid FROM $table_name WHERE ('$from' BETWEEN `fromdate` AND `todate`) AND  ('$to' BETWEEN `fromdate` AND `todate`) AND status = 'R' )" ); 


   }
   
$contain = array();

foreach ( $cont as $con ) 


{


$comps = array(

      'ERROR' => "",
      'room' => "$con->name",
      'description' => "$con->description",
      'price' => "$con->price",
      'rID' => "$con->rid",

      );

array_push($contain,$comps);



}


array_push($container,$contain);

$table_name = $wpdb->prefix . 'db_coupons';

$cpns = $wpdb->get_results( "SELECT * FROM $table_name WHERE (('$from' BETWEEN `validdate` AND `exdate`) AND ('$to' BETWEEN `validdate` AND `exdate`)) OR (token = '$_REQUEST[promo]' AND token <> '' )
 " );
   
   
$contain = array();

if(empty($cpns)){ 


$comps = array(

      'ERROR' => "",
      'offer' => "",
      'description' => "",
      'price' => "",
      'cID' => "",

      );

array_push($contain,$comps); array_push($container,$contain);



 } else {  
   

foreach ( $cpns as $con ) 


{


$comps = array(

      'ERROR' => "",
      'offer' => "$con->name",
      'description' => "$con->description",
      'cID' => "$con->cid",

      );

array_push($contain,$comps);






}

array_push($container,$contain);


 }


$table_name = $wpdb->prefix . 'db_add_ons';

$addOns = $wpdb->get_results( "SELECT * FROM $table_name  " ); 

$contain = array();

foreach ( $addOns as $addOn ) 


{





      $comps = array(

     
      'ERROR' => "",
      'AID' => "$addOn->aid",
      'ADD_ON_NAME' => "$addOn->name",
      'PRICE' => "$addOn->price",
      'FREQUENCY' => "$addOn->frequency",
      'DESCRIPTION' => "$addOn->description",
      'RESID' => "$resID->resid",
      'NAME' => "$_REQUEST[firstname] $_REQUEST[lastname]",

       );

array_push($contain,$comps);

     
}

     

      
      array_push($container,$contain);



   echo json_encode($container);

 


?>
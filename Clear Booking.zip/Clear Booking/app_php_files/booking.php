<?php

   header("Access-Control-Allow-Origin: *");

   header("Content-Type: application/json; charset=UTF-8");

   $path = $_SERVER['DOCUMENT_ROOT'];

   include_once $path . '/wp-config.php';

   include_once $path . '/wp-load.php';

   include_once $path . '/wp-includes/wp-db.php';

   include_once $path . '/wp-includes/pluggable.php';

include_once $path . '/wp-includes/http.php';

  
   global $wpdb;


function crypto_rand_secure($min, $max)
{
    $range = $max - $min;
    if ($range < 1) return $min; // not so random...
    $log = ceil(log($range, 2));
    $bytes = (int) ($log / 8) + 1; // length in bytes
    $bits = (int) $log + 1; // length in bits
    $filter = (int) (1 << $bits) - 1; // set all lower bits to 1
    do {
        $rnd = hexdec(bin2hex(openssl_random_pseudo_bytes($bytes)));
        $rnd = $rnd & $filter; // discard irrelevant bits
    } while ($rnd >= $range);
    return $min + $rnd;
}

function getToken($length)
{
    $token = "";
    $codeAlphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    $codeAlphabet.= "abcdefghijklmnopqrstuvwxyz";
    $codeAlphabet.= "0123456789";
    $max = strlen($codeAlphabet) - 1;
    for ($i=0; $i < $length; $i++) {
        $token .= $codeAlphabet[crypto_rand_secure(0, $max)];
    }
    return $token;
}

   $checkintoken = getToken(7);
 
   $table_name = $wpdb->prefix . 'db_reservations';

   $wpdb->update( 
   $table_name, 
   array( 
              
                'firstname'=>$_REQUEST[firstname],
                'lastname'=>$_REQUEST[lastname],
                'phone'=>$_REQUEST[phone],
                'email'=>$_REQUEST[email],
                'checkintoken'=>$checkintoken,
                
  
  ),
   array( 'resid' => $_REQUEST[resID] ) );

      $table_name = $wpdb->prefix . 'db_reservations';

      $mylink = $wpdb->get_row( "SELECT * FROM $table_name WHERE resid = '$_REQUEST[resID]'" );


      $total = number_format($mylink->total,2, '.', ',');
     
      $contain = array();

      $container = array();

      $comps = array(

     
      'ERROR' => "",
      'RESID' => "$_REQUEST[resID]",
      'NAME' => "$_REQUEST[firstname] $_REQUEST[lastname]",
      'TOTAL' => "$total",

       );

      array_push($contain,$comps);
      
      array_push($container,$contain);

      echo json_encode($container);


    

     




?>
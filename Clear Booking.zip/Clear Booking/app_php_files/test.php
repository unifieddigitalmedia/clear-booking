<?php

header("Access-Control-Allow-Origin: *");

   header("Content-Type: application/json; charset=UTF-8");


$url = "https://gcm-http.googleapis.com/gcm/send";
$content_type = "application/json";
$Auth_key ="key=AIzaSyAKmCPpcSUb4L5cSZJvwXuMAwGtoK3WLG8";

$ch = curl_init();

echo "initialised";



?>
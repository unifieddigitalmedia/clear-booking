<?php

   header("Access-Control-Allow-Origin: *");

   header("Content-Type: application/json; charset=UTF-8");

   $path = $_SERVER['DOCUMENT_ROOT'];

   include_once $path . '/wp-config.php';

   include_once $path . '/wp-load.php';

   include_once $path . '/wp-includes/wp-db.php';

   include_once $path . '/wp-includes/pluggable.php';

   global $wpdb;

   $wpdb->show_errors();

   $table_name = $wpdb->prefix . 'db_reservations';

   $wpdb->update( 

   $table_name, 

   array('devicetoken'=>$_REQUEST[token]),

   array('checkintoken' => $_REQUEST[checkin_token])
  
    );

$wpdb->print_error();

?>
<?php


   header("Access-Control-Allow-Origin: *");

   header("Content-Type: application/json; charset=UTF-8");

   $path = $_SERVER['DOCUMENT_ROOT'];

   include_once $path . '/wp-config.php';

   include_once $path . '/wp-load.php';

   include_once $path . '/wp-includes/wp-db.php';

   include_once $path . '/wp-includes/pluggable.php';

include_once $path . '/wp-includes/http.php';

  
   global $wpdb;


      $table_name = $wpdb->prefix . 'db_reservations';

      $mylink = $wpdb->get_row( "SELECT * FROM $table_name WHERE checkintoken = '$_REQUEST[checkintoken]'" );

$contain = array();

      $container = array();


if ($wpdb->num_rows > 0)
{

$comps = array(

     
      'ERROR' => "",
      'NAME' => "$mylink->firstname $mylink->lastname",
     
       );

}
else
{


$comps = array(

     
      'ERROR' => "No reservation found", 'NAME' => "$_REQUEST[firstname] $_REQUEST[lastname]",
     
       );


}

      

      

      array_push($contain,$comps);
      
      array_push($container,$contain);

      echo json_encode($container);







?>
<?php

   header("Access-Control-Allow-Origin: *");

   header("Content-Type: application/json; charset=UTF-8");

   $path = $_SERVER['DOCUMENT_ROOT'];

   include_once $path . '/wp-config.php';

   include_once $path . '/wp-load.php';

   include_once $path . '/wp-includes/wp-db.php';

   include_once $path . '/wp-includes/pluggable.php';

  
   global $wpdb;

   $date = str_replace('/', '-',$_REQUEST[from]);

   $from = date('Y-m-d', strtotime($date));



   $date1 = str_replace('/', '-',$_REQUEST[to]);

   $to = date('Y-m-d', strtotime($date1));



   $diff = abs(strtotime($to) - strtotime($from));

   $years = floor($diff / (365*60*60*24));

   $months = floor(($diff - $years * 365*60*60*24) / (30*60*60*24));

   $days = floor(($diff - $years * 365*60*60*24 - $months*30*60*60*24)/ (60*60*24));

   $timeheld = date("Y-m-d h:s:i");

$rm_found = true;

$table_name = $wpdb->prefix . 'db_bookings';

   $cont = $wpdb->get_results( "SELECT rid FROM $table_name WHERE ('$from' BETWEEN `from` AND `to`) AND  ('$to' BETWEEN `from` AND `to`) AND status <> 'R' " );

foreach ($_REQUEST[rooms] as $rmvalue )


{


for ($x  = 0; $x < $cont.length; $x ++  )


{


if( $cont[$x] === $rmvalue )

{


$rm_found = false;


}




}



}


if($rm_found) {





      $amt = 0;

$addons = array();

$addAmt = 0;

for ($x = 0; $x < sizeof($_REQUEST[addon]); $x++  ) 

{

$table_name = $wpdb->prefix . 'db_add_ons';

$nm = $_REQUEST[addon][$x];

$addrow = $wpdb->get_row( "SELECT * FROM $table_name WHERE aid = '$nm' " ); 
  
if($addrow->frequency == 'night')

{

$amt = ($addrow->price * $days);

$addAmt = $addAmt + $amt;

}

else if ($addrow->frequency == 'person')

{


$table_name1 = $wpdb->prefix . 'db_reservations';

$num_adlts = $wpdb->get_row( "SELECT * FROM $table_name1 WHERE resid = '$_REQUEST[resID]' " ); 

$amt = ($addrow->price * $num_adlts->adults);

$addAmt = $addAmt + $amt;



}

else if($addrow->frequency == 'room')

{



$table_name2 = $wpdb->prefix . 'db_bookings';

$room_count = $wpdb->get_var( "SELECT COUNT(*) FROM $table_name2 WHERE resid = '$_REQUEST[resID]'" );

$amt = ($addrow->price * $room_count);

$addAmt = $addAmt + $amt;



}




$table_name = $wpdb->prefix . 'db_reservation_add_ons';
 
$wpdb->insert( 
   
         $table_name, 
  
         array( 

                'resid' => $_REQUEST[resID],
                'aid' => $addrow->aid,
                'amount'=> $amt,

              ) 
  
    );

}


$table_name1 = $wpdb->prefix . 'db_reservations';

$num_adlts = $wpdb->get_row( "SELECT * FROM $table_name1 WHERE resid = '$_REQUEST[resID]' " ); 

$total = $num_adlts->total + $addAmt;

   $wpdb->update( 

   $table_name1, 

   array('total'=>$total,'addOnAmt'=>$addAmt),

   array('resid' => $_REQUEST[resID])
  
    );


      $contain = array(

     
      'ERROR' => "",
      'RESID' => "$_REQUEST[resID]",
     

       );



      array_push($container,$contain);

      echo json_encode($container);


}

else

{



      $contain = array();


      $comps = array(

     
      'ERROR' => "One or more of your rooms has been reserved",
      'RESID' => "",
      'NAME' => "",
     

       );


      array_push($contain,$comps);

      array_push($container,$contain);

      echo json_encode($container);


}
      
      

    

     




?>
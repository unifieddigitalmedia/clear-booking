<?php

   header("Access-Control-Allow-Origin: *");

   header("Content-Type: application/json; charset=UTF-8");

   $path = $_SERVER['DOCUMENT_ROOT'];

   include_once $path . '/wp-config.php';

   include_once $path . '/wp-load.php';

   include_once $path . '/wp-includes/wp-db.php';

   include_once $path . '/wp-includes/pluggable.php';

  
   global $wpdb;

   $date = str_replace('/', '-',$_REQUEST[from]);

   $from = date('Y-m-d', strtotime($date));



   $date1 = str_replace('/', '-',$_REQUEST[to]);

   $to = date('Y-m-d', strtotime($date1));



   $diff = abs(strtotime($to) - strtotime($from));

   $years = floor($diff / (365*60*60*24));

   $months = floor(($diff - $years * 365*60*60*24) / (30*60*60*24));

   $days = floor(($diff - $years * 365*60*60*24 - $months*30*60*60*24)/ (60*60*24));

   $timeheld = date("Y-m-d h:s:i");

$rm_found = true;

$table_name = $wpdb->prefix . 'db_bookings';

   $cont = $wpdb->get_results( "SELECT rid FROM $table_name WHERE ('$from' BETWEEN `from` AND `to`) AND  ('$to' BETWEEN `from` AND `to`) AND status <> 'R' " );

foreach ($_REQUEST[rooms] as $rmvalue )


{


for ($x  = 0; $x < $cont.length; $x ++  )


{


if( $cont[$x] === $rmvalue )

{


$rm_found = false;


}




}



}


if($rm_found) {


  $table_name = $wpdb->prefix . 'db_reservations';
   
  $wpdb->insert( 
   
         $table_name, 

         array( 

                'fromdate' => $from,
                'todate' => $to,
                'dateheld'=>$timeheld,
                'lengthofstay'=>$days,
                

               ) 
  
    );

       



      $resID = $wpdb->get_row( "SELECT resid FROM $table_name WHERE dateheld = '$timeheld' " );


      $total = 0;

      

      $contain = array();

      $container = array();

      foreach ($_REQUEST[rooms] as $value)

      {

       $table_name = $wpdb->prefix . 'db_rooms';

       $price = 0;

       $cont = $wpdb->get_row( "SELECT * FROM $table_name WHERE rid = '$value' " ); 



       $comps = array(

      'ERROR' => "",
      'room' => "$cont->name",
      'description' => "$cont->description",
      'price' => "$cont->price",
      'rID' => "$cont->rid",
      'lengthofstay'=>$days,
      'RESID' => "$resID->resid"

      );

      array_push($contain,$comps);


       $price = $days * $cont->price;

       $total = $total + $price;

       $table_name = $wpdb->prefix . 'db_bookings';

       $wpdb->insert( 

       $table_name, 

       array( 

    'rid' => $value, 

    'fromdate' => $from,
                'todate' => $to,
                'status'=>'H',
                'resid'=>$resID->resid
        ) 
  
          );
      
      }


       array_push($container,$contain);

       $contain = array();
       
       $table_name = $wpdb->prefix . 'db_coupons';

       $dsc = 0 ;

       foreach ($_REQUEST[offers] as $value)

      {

      
       $cont = $wpdb->get_row( "SELECT * FROM $table_name WHERE cid = '$value' " ); 

       $comps = array( 'ERROR' => "", 'offer' => "$cont->name", 'description' => "$cont->description", 'cID' => "$cont->cid" ,'RESID' => "$resID->resid",'lengthofstay'=>$days);

           array_push($contain,$comps);

       $amt = (($total * $cont->amount)/100);

       $dsc = $dsc + $amt;

       $total = $total - $amt;
       
       $table_name = $wpdb->prefix . 'db_reservation_coupons';

       $wpdb->insert( 

       $table_name, 

       array( 

       'cid' => $value, 

       'resid'=>$resID->resid

       ) 
  
       );
       
      
      }

 




 array_push($container,$contain);

       $contain = array();



$amt = 0;

$addons = array();

$addAmt = 0;

for ($x = 0; $x < sizeof($_REQUEST[addon]); $x++  ) 

{

$table_name = $wpdb->prefix . 'db_add_ons';

$nm = $_REQUEST[addon][$x];

$addrow = $wpdb->get_row( "SELECT * FROM $table_name WHERE aid = '$nm' " ); 
  


$comps = array(

     
      'ERROR' => "",
      'AID' => "$addrow->aid",
      'ADD_ON_NAME' => "$addrow->name",
      'PRICE' => "$addrow->price",
      'FREQUENCY' => "$addrow->frequency",
      'lengthofstay'=>$days,
      'DESCRIPTION' => "$addrow->description",
      'RESID' => "$resID->resid",
     

       );

array_push($contain,$comps);

if($addrow->frequency == 'night')

{


$amt = ($addrow->price * $days);

$addAmt = $addAmt + $amt;


}

else if ($addrow->frequency == 'person')

{



$amt = ($addrow->price * $_REQUEST[guests]);

$addAmt = $addAmt + $amt;



}

else if($addrow->frequency == 'room')

{



$room_count = sizeof($_REQUEST[rooms]);

$amt = ($addrow->price * $room_count);

$addAmt = $addAmt + $amt;



}


 

$table_name = $wpdb->prefix . 'db_reservation_add_ons';
 
$wpdb->insert( 
   
         $table_name, 
  
         array( 

                'resid' => $resID->resid,
                'aid' => $addrow->aid,
                'amount'=> $amt,

              ) 
  
    );


}


array_push($container,$contain);

   $total = $total + $addAmt ;


   $table_name = $wpdb->prefix . 'db_reservations';


  

   $wpdb->update( 

   $table_name, 

   array('total'=>$total,'discount'=>$dsc,'addOnAmt'=>$addAmt),

   array('resid' => $resID->resid)
  
    );


 $total = number_format($total,2, '.', ',');

$contain = array();

$comps = array(

     
      'TOTAL' => "$total",
      'DISCOUNT' => "$dsc",
      'RESID' => "$resID->resid",
     

       );

array_push($contain,$comps);
      

array_push($container,$contain);
      /*$comps = array(

     
      'ERROR' => "",
      'RESID' => "$resID->resid",
      
      
       );

      array_push($contain,$comps);

      array_push($container,$contain);*/

      echo json_encode($container);


}

else

{



      $contain = array();


      $comps = array(

     
      'ERROR' => "One or more of your rooms has been reserved",
      'RESID' => "",
      'NAME' => "",
     

       );


      array_push($contain,$comps);

      array_push($container,$contain);

      echo json_encode($container);


}
      
      

    

     




?>
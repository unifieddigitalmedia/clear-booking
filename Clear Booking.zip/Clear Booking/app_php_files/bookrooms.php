<?php

   header("Access-Control-Allow-Origin: *");

   header("Content-Type: application/json; charset=UTF-8");

   $path = $_SERVER['DOCUMENT_ROOT'];

   include_once $path . '/wp-config.php';

   include_once $path . '/wp-load.php';

   include_once $path . '/wp-includes/wp-db.php';

   include_once $path . '/wp-includes/pluggable.php';

  
    global $wpdb;

   $date = str_replace('/', '-',$_REQUEST[from]);

   $from = date('Y-m-d', strtotime($date));



   $date1 = str_replace('/', '-',$_REQUEST[to]);

   $to = date('Y-m-d', strtotime($date1));



   $diff = abs(strtotime($to) - strtotime($from));

   $years = floor($diff / (365*60*60*24));

   $months = floor(($diff - $years * 365*60*60*24) / (30*60*60*24));

   $days = floor(($diff - $years * 365*60*60*24 - $months*30*60*60*24)/ (60*60*24));


      $total = 0;

      $table_name = $wpdb->prefix . 'db_rooms';

      $contain = array();

      $container = array();

      foreach ($_REQUEST[rooms] as $value)

      {

       $price = 0;

       $cont = $wpdb->get_row( "SELECT * FROM $table_name WHERE rid = '$value' " ); 

       $price = $days * $cont->price;

       $total = $total + $price;

       $comps = array(

     
      'ERROR' => "",
      'room' => "$cont->name",
      'price' => "$price",
      'total' => "$total",
      'ID' => "$value",
     

       );


       array_push($contain,$comps);

       
      
      }

       array_push($container,$contain);


$contain = array();

       $table_name = $wpdb->prefix . 'db_coupons';

       foreach ($_REQUEST[offers] as $value)

      {

      
       $cont = $wpdb->get_row( "SELECT * FROM $table_name WHERE cid = '$value' " ); 

       
       $amt = (($total * $cont->amount)/100);

       $total = $total - (($total * $cont->amount)/100);

       $comps = array(

     
      'ERROR' => "",
      'offer' => "$cont->name",
      'amount' => "($amt)",
      'ID' => "$value",
     

       );


       array_push($contain,$comps);

       
      
      }

      array_push($container,$contain);


      $contain = array();


      $comps = array(

     
      'ERROR' => "",
      'offer' => "$cont->name",
      'total' => "$total",
     

       );


      array_push($contain,$comps);

      array_push($container,$contain);

      echo json_encode($container);


?>